import SwiftUI
import AppKit

@main
struct DotTrackpadMacApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate

    var body: some Scene {
        MenuBarExtra("Dot Trackpad", systemImage: "circle.grid.3x3") {
            MenuContent(model: AppModel.shared)
        }
    }
}

/// Menu: connection status, Accessibility status, Quit.
struct MenuContent: View {
    @ObservedObject var model: AppModel

    var body: some View {
        Text(model.connectionStatus)
        Text(model.accessibilityTrusted
             ? "Accessibility: allowed"
             : "Accessibility: NOT allowed (System Settings > Privacy & Security > Accessibility)")
        Divider()
        Button("Quit") {
            NSApplication.shared.terminate(nil)
        }
        .keyboardShortcut("q")
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate {
    func applicationDidFinishLaunching(_ notification: Notification) {
        AppModel.shared.start()
    }
}
