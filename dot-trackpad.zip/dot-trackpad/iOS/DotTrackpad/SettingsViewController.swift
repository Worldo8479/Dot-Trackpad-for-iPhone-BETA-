import UIKit

/// The settings panel opened by the gear icon.
final class SettingsViewController: UITableViewController {
    var onDone: (() -> Void)?

    private struct SliderSpec {
        let title: String
        let range: ClosedRange<Double>
        let get: () -> Double
        let set: (Double) -> Void
        let format: (Double) -> String
    }

    private enum Row {
        case slider(SliderSpec)
        case toggle(title: String, get: () -> Bool, set: (Bool) -> Void)
        case hotkey(title: String, target: AppTarget)
    }

    private struct Section {
        let title: String
        let footer: String?
        let rows: [Row]
    }

    private var sections: [Section] = []

    init() {
        super.init(style: .insetGrouped)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Settings"
        navigationItem.rightBarButtonItem = UIBarButtonItem(systemItem: .done, primaryAction: UIAction { [weak self] _ in
            self?.onDone?()
        })
        tableView.keyboardDismissMode = .onDrag
        buildSections()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData() // app assignments may have changed in the picker
        AppCatalog.shared.request()
    }

    private func buildSections() {
        sections = [
            Section(title: "Dot grid", footer: nil, rows: [
                .slider(SliderSpec(title: "Dot spacing", range: AppSettings.spacingRange,
                                   get: { AppSettings.dotSpacing },
                                   set: { AppSettings.dotSpacing = $0.rounded() },
                                   format: { String(format: "%.0f pt", $0) })),
                .slider(SliderSpec(title: "Dot size", range: AppSettings.dotSizeRange,
                                   get: { AppSettings.dotSize },
                                   set: { AppSettings.dotSize = ($0 * 10).rounded() / 10 },
                                   format: { String(format: "%.1f pt", $0) })),
                .slider(SliderSpec(title: "Growth under finger", range: AppSettings.growthRange,
                                   get: { AppSettings.growth },
                                   set: { AppSettings.growth = ($0 * 10).rounded() / 10 },
                                   format: { String(format: "+%.1f pt", $0) })),
                .slider(SliderSpec(title: "Highlight radius", range: AppSettings.radiusRange,
                                   get: { AppSettings.highlightRadius },
                                   set: { AppSettings.highlightRadius = $0.rounded() },
                                   format: { String(format: "%.0f pt", $0) })),
            ]),
            Section(title: "Feel", footer: nil, rows: [
                .toggle(title: "Haptics", get: { AppSettings.hapticsEnabled }, set: { AppSettings.hapticsEnabled = $0 }),
                .slider(SliderSpec(title: "Pointer speed", range: AppSettings.speedRange,
                                   get: { AppSettings.pointerSpeed },
                                   set: { AppSettings.pointerSpeed = ($0 * 10).rounded() / 10 },
                                   format: { String(format: "%.1f×", $0) })),
            ]),
            Section(title: "Typing",
                    footer: "When the Mac has a text field focused, a keyboard pops up on this iPhone. Turn this off if you use a physical keyboard.",
                    rows: [
                .toggle(title: "Show keyboard for text fields",
                        get: { AppSettings.keyboardEnabled }, set: { AppSettings.keyboardEnabled = $0 }),
            ]),
            Section(title: "Hotkey strip",
                    footer: "Tap a slot to rename it, change what it does (open a Mac app or press a keyboard shortcut) or clear it. Assigned slots appear as buttons below the grid.",
                    rows: (0..<AppSettings.slotCount).map { Row.hotkey(title: "Slot \($0 + 1)", target: .slot($0)) }),
            Section(title: "Edge swipes",
                    footer: "Drag down, starting just inside the left or right edge of the dot grid, to run the hotkey (an app or a keyboard shortcut). Dragging inward from those edges always shows the Mac volume (left) / brightness (right) slider.",
                    rows: [
                .hotkey(title: "Left edge, swipe down", target: .edge(.left)),
                .hotkey(title: "Right edge, swipe down", target: .edge(.right)),
            ]),
        ]
    }

    // MARK: Table data

    override func numberOfSections(in tableView: UITableView) -> Int { sections.count }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        sections[section].rows.count
    }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        sections[section].title
    }

    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        sections[section].footer
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch sections[indexPath.section].rows[indexPath.row] {
        case .slider(let spec):
            return SliderCell(spec: spec)
        case .toggle(let title, let get, let set):
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            cell.textLabel?.text = title
            cell.selectionStyle = .none
            let toggle = UISwitch()
            toggle.isOn = get()
            toggle.addAction(UIAction { [weak toggle] _ in
                if let toggle = toggle { set(toggle.isOn) }
            }, for: .valueChanged)
            cell.accessoryView = toggle
            return cell
        case .hotkey(let title, let target):
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            cell.textLabel?.text = title
            if let hotkey = AppSettings.hotkey(for: target) {
                cell.detailTextLabel?.text = hotkey.displayName
            } else {
                cell.detailTextLabel?.text = "Not assigned"
            }
            cell.accessoryType = .disclosureIndicator
            return cell
        }
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if case .hotkey(let title, let target) = sections[indexPath.section].rows[indexPath.row] {
            navigationController?.pushViewController(HotkeyEditorViewController(title: title, target: target), animated: true)
        }
    }

    // MARK: Slider cell

    private final class SliderCell: UITableViewCell {
        init(spec: SliderSpec) {
            super.init(style: .default, reuseIdentifier: nil)
            selectionStyle = .none

            let titleLabel = UILabel()
            titleLabel.text = spec.title
            titleLabel.font = .preferredFont(forTextStyle: .body)

            let valueLabel = UILabel()
            valueLabel.font = .monospacedDigitSystemFont(ofSize: 15, weight: .regular)
            valueLabel.textColor = .secondaryLabel
            valueLabel.textAlignment = .right

            let slider = UISlider()
            slider.minimumValue = Float(spec.range.lowerBound)
            slider.maximumValue = Float(spec.range.upperBound)
            slider.value = Float(spec.get())
            valueLabel.text = spec.format(spec.get())
            slider.addAction(UIAction { [weak slider, weak valueLabel] _ in
                guard let slider = slider else { return }
                spec.set(Double(slider.value))
                valueLabel?.text = spec.format(spec.get())
            }, for: .valueChanged)

            let top = UIStackView(arrangedSubviews: [titleLabel, valueLabel])
            top.axis = .horizontal
            top.distribution = .fill
            let stack = UIStackView(arrangedSubviews: [top, slider])
            stack.axis = .vertical
            stack.spacing = 6
            stack.translatesAutoresizingMaskIntoConstraints = false
            contentView.addSubview(stack)
            NSLayoutConstraint.activate([
                stack.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 10),
                stack.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: -10),
                stack.leadingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.leadingAnchor),
                stack.trailingAnchor.constraint(equalTo: contentView.layoutMarginsGuide.trailingAnchor),
            ])
        }

        required init?(coder: NSCoder) {
            fatalError("init(coder:) is not used")
        }
    }
}
