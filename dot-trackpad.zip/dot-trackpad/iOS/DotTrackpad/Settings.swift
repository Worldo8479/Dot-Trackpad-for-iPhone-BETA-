import Foundation

/// What a settings row assigns a hotkey to.
enum AppTarget: Equatable {
    case slot(Int)                          // hotkey strip slot 0 ..< AppSettings.slotCount
    case edge(EdgeSwipeDetector.Edge)       // left / right edge swipe
}

/// All user settings, persisted in UserDefaults. Setters post `AppSettings.didChange`
/// so the dot grid, hotkey strip and keyboard can update live.
enum AppSettings {
    static let didChange = Notification.Name("DotTrackpadSettingsDidChange")

    /// Overridable so tests can use a throw-away suite.
    static var defaults: UserDefaults = .standard

    static let slotCount = 6

    // Ranges and defaults
    static let spacingRange: ClosedRange<Double> = 14...40
    static let dotSizeRange: ClosedRange<Double> = 0.6...3.0
    static let growthRange: ClosedRange<Double> = 0...6
    static let radiusRange: ClosedRange<Double> = 40...160
    static let speedRange: ClosedRange<Double> = 0.5...3.0

    static let spacingDefault = 24.0
    static let dotSizeDefault = 1.2
    static let growthDefault = 2.2
    static let radiusDefault = 90.0
    static let speedDefault = 1.0

    private enum Key {
        static let keyboard = "show_keyboard"
        static let haptics = "haptics_enabled"
        static let spacing = "dot_spacing"
        static let dotSize = "dot_size"
        static let growth = "dot_growth"
        static let radius = "highlight_radius"
        static let speed = "pointer_speed"
    }

    private static func readDouble(_ key: String, _ range: ClosedRange<Double>, _ fallback: Double) -> Double {
        guard let value = defaults.object(forKey: key) as? Double, value.isFinite else { return fallback }
        return min(max(value, range.lowerBound), range.upperBound)
    }

    private static func writeDouble(_ key: String, _ range: ClosedRange<Double>, _ value: Double) {
        guard value.isFinite else { return }
        defaults.set(min(max(value, range.lowerBound), range.upperBound), forKey: key)
        changed()
    }

    private static func readBool(_ key: String, _ fallback: Bool) -> Bool {
        (defaults.object(forKey: key) as? Bool) ?? fallback
    }

    private static func writeBool(_ key: String, _ value: Bool) {
        defaults.set(value, forKey: key)
        changed()
    }

    static func changed() {
        NotificationCenter.default.post(name: didChange, object: nil)
    }

    // MARK: Typing / feel

    static var keyboardEnabled: Bool {
        get { readBool(Key.keyboard, true) }
        set { writeBool(Key.keyboard, newValue) }
    }

    static var hapticsEnabled: Bool {
        get { readBool(Key.haptics, true) }
        set { writeBool(Key.haptics, newValue) }
    }

    static var pointerSpeed: Double {
        get { readDouble(Key.speed, speedRange, speedDefault) }
        set { writeDouble(Key.speed, speedRange, newValue) }
    }

    // MARK: Dot grid

    /// Distance between neighbouring dots (points).
    static var dotSpacing: Double {
        get { readDouble(Key.spacing, spacingRange, spacingDefault) }
        set { writeDouble(Key.spacing, spacingRange, newValue) }
    }

    /// Radius of an idle dot (points).
    static var dotSize: Double {
        get { readDouble(Key.dotSize, dotSizeRange, dotSizeDefault) }
        set { writeDouble(Key.dotSize, dotSizeRange, newValue) }
    }

    /// Extra radius a dot gains directly under the finger (points).
    static var growth: Double {
        get { readDouble(Key.growth, growthRange, growthDefault) }
        set { writeDouble(Key.growth, growthRange, newValue) }
    }

    /// How far from the finger dots react (points).
    static var highlightRadius: Double {
        get { readDouble(Key.radius, radiusRange, radiusDefault) }
        set { writeDouble(Key.radius, radiusRange, newValue) }
    }

    // MARK: Hotkeys (strip slots and edge swipes)

    private static func key(for target: AppTarget) -> String? {
        switch target {
        case .slot(let index):
            return (0..<slotCount).contains(index) ? "hotkey_slot_\(index)" : nil
        case .edge(let edge):
            return "edge_app_\(edge.rawValue)"
        }
    }

    /// The hotkey stored for a slot / edge, or nil when unassigned.
    ///
    /// Migration: versions up to 1.2 stored a bare JSON `AppInfo` ({"name":…,"bundleId":…}) under these
    /// keys. Such a value is read as an "Open app" hotkey with no custom name and rewritten in the new
    /// format (JSON `Hotkey`: {"name"?, "action":{"type":"app"|"shortcut", …}}) on first read.
    /// Unreadable or invalid data counts as unassigned.
    static func hotkey(for target: AppTarget) -> Hotkey? {
        guard let key = key(for: target), let data = defaults.data(forKey: key) else { return nil }
        let decoder = JSONDecoder()
        if let hotkey = try? decoder.decode(Hotkey.self, from: data) {
            return hotkey.isValid ? hotkey : nil
        }
        if let legacy = try? decoder.decode(AppInfo.self, from: data), !legacy.bundleId.isEmpty {
            let migrated = Hotkey(name: nil, action: .app(legacy))
            if let upgraded = try? JSONEncoder().encode(migrated) {
                defaults.set(upgraded, forKey: key)
            }
            return migrated
        }
        return nil
    }

    /// Stores (or, with nil, clears) the hotkey for a slot / edge. Invalid hotkeys are treated as clearing.
    static func setHotkey(_ hotkey: Hotkey?, for target: AppTarget) {
        guard let key = key(for: target) else { return }
        if var hotkey = hotkey, hotkey.isValid {
            hotkey.name = Hotkey.cleanedName(hotkey.name)
            if let data = try? JSONEncoder().encode(hotkey) {
                defaults.set(data, forKey: key)
            }
        } else {
            defaults.removeObject(forKey: key)
        }
        changed()
    }

    static func edgeHotkey(_ edge: EdgeSwipeDetector.Edge) -> Hotkey? {
        hotkey(for: .edge(edge))
    }
}
