import Foundation
import CoreGraphics
import AppKit

/// Turns `Message`s into CGEvents. Not thread-safe: call from one queue only.
/// Requires Accessibility permission (events are silently dropped without it).
final class InputInjector {
    private enum KeyCode {
        static let equal: CGKeyCode = 24      // kVK_ANSI_Equal
        static let minus: CGKeyCode = 27      // kVK_ANSI_Minus
        static let returnKey: CGKeyCode = 36  // kVK_Return
        static let delete: CGKeyCode = 51     // kVK_Delete (backspace)
    }

    /// Pinch travel (phone points) needed for one Cmd+= / Cmd+- step.
    private static let zoomStep = 30.0

    private let source = CGEventSource(stateID: .hidSystemState)
    private var lastPostedPosition: CGPoint?
    private var scrollRemainderX = 0.0
    private var scrollRemainderY = 0.0
    private var zoomAccumulator = 0.0
    private var lastClick: (button: CGMouseButton, time: TimeInterval, location: CGPoint, count: Int)?

    func handle(_ message: Message) {
        switch message.kind {
        case .move:
            moveCursor(dx: message.dx ?? 0, dy: message.dy ?? 0)
        case .click:
            click(button: .left)
        case .rightClick:
            click(button: .right)
        case .scroll:
            scroll(dx: message.dx ?? 0, dy: message.dy ?? 0)
        case .zoom:
            zoom(delta: message.dx ?? 0)
        case .text:
            if let text = message.text { type(text) }
        case .key:
            switch message.key {
            case .backspace?: pressKey(KeyCode.delete)
            case .returnKey?: pressKey(KeyCode.returnKey)
            case nil: break
            }
        case .keyShortcut:
            if let code = message.keyCode { pressShortcut(keyCode: code, modifiers: message.modifiers ?? 0) }
        case .focus, .requestApps, .appList, .openApp, .getLevels, .levels, .setVolume, .setBrightness:
            break // not input events (app messages are handled by AppModel; focus is Mac -> iPhone)
        }
    }

    // MARK: Mouse

    private func currentLocation() -> CGPoint? {
        CGEvent(source: nil)?.location
    }

    private func displayBounds() -> CGRect {
        var count: UInt32 = 0
        CGGetActiveDisplayList(0, nil, &count)
        guard count > 0 else { return CGDisplayBounds(CGMainDisplayID()) }
        var ids = [CGDirectDisplayID](repeating: 0, count: Int(count))
        CGGetActiveDisplayList(count, &ids, &count)
        var union = CGRect.null
        for id in ids.prefix(Int(count)) {
            union = union.union(CGDisplayBounds(id))
        }
        return union.isNull ? CGDisplayBounds(CGMainDisplayID()) : union
    }

    private func moveCursor(dx: Double, dy: Double) {
        guard let actual = currentLocation() else { return }

        // Keep our own sub-pixel position so slow movements are not lost to rounding,
        // but re-sync if the user moved the cursor some other way (physical mouse).
        var base = actual
        if let last = lastPostedPosition, hypot(actual.x - last.x, actual.y - last.y) < 3 {
            base = last
        }

        let bounds = displayBounds()
        let x = min(max(base.x + dx, bounds.minX), bounds.maxX - 1)
        let y = min(max(base.y + dy, bounds.minY), bounds.maxY - 1)
        let target = CGPoint(x: x, y: y)

        if let event = CGEvent(mouseEventSource: source, mouseType: .mouseMoved,
                               mouseCursorPosition: target, mouseButton: .left) {
            event.setIntegerValueField(.mouseEventDeltaX, value: Int64(dx.rounded()))
            event.setIntegerValueField(.mouseEventDeltaY, value: Int64(dy.rounded()))
            event.post(tap: .cghidEventTap)
        }
        lastPostedPosition = target
    }

    private func click(button: CGMouseButton) {
        guard let location = currentLocation() else { return }

        // Consecutive quick taps in the same place become double / triple clicks.
        let now = ProcessInfo.processInfo.systemUptime
        var count = 1
        if let last = lastClick, last.button == button,
           now - last.time <= NSEvent.doubleClickInterval,
           hypot(location.x - last.location.x, location.y - last.location.y) < 5 {
            count = last.count + 1
        }
        lastClick = (button, now, location, count)

        let downType: CGEventType = button == .left ? .leftMouseDown : .rightMouseDown
        let upType: CGEventType = button == .left ? .leftMouseUp : .rightMouseUp
        for type in [downType, upType] {
            guard let event = CGEvent(mouseEventSource: source, mouseType: type,
                                      mouseCursorPosition: location, mouseButton: button) else { continue }
            event.setIntegerValueField(.mouseEventClickState, value: Int64(count))
            event.post(tap: .cghidEventTap)
        }
    }

    // MARK: Scroll and zoom

    private func scroll(dx: Double, dy: Double) {
        // Positive wheel1 scrolls content down (towards the top of the document), which is
        // what a finger dragging downwards should do ("natural" direction).
        scrollRemainderX += min(max(dx, -2000), 2000)
        scrollRemainderY += min(max(dy, -2000), 2000)
        let wholeX = Int32(scrollRemainderX.rounded(.towardZero))
        let wholeY = Int32(scrollRemainderY.rounded(.towardZero))
        guard wholeX != 0 || wholeY != 0 else { return }
        scrollRemainderX -= Double(wholeX)
        scrollRemainderY -= Double(wholeY)

        CGEvent(scrollWheelEvent2Source: source, units: .pixel, wheelCount: 2,
                wheel1: wholeY, wheel2: wholeX, wheel3: 0)?
            .post(tap: .cghidEventTap)
    }

    /// Pinch is mapped to the universal Cmd+= (zoom in) / Cmd+- (zoom out) shortcuts.
    private func zoom(delta: Double) {
        zoomAccumulator += min(max(delta, -150), 150)
        while zoomAccumulator >= Self.zoomStep {
            pressKey(KeyCode.equal, flags: .maskCommand)
            zoomAccumulator -= Self.zoomStep
        }
        while zoomAccumulator <= -Self.zoomStep {
            pressKey(KeyCode.minus, flags: .maskCommand)
            zoomAccumulator += Self.zoomStep
        }
    }

    // MARK: Keyboard

    private func pressKey(_ code: CGKeyCode, flags: CGEventFlags = []) {
        for keyDown in [true, false] {
            guard let event = CGEvent(keyboardEventSource: source, virtualKey: code, keyDown: keyDown) else { continue }
            event.flags = flags
            event.post(tap: .cghidEventTap)
        }
    }

    /// Posts a key press with modifier flags (from the phone's hotkey strip / edge swipe).
    private func pressShortcut(keyCode: Int, modifiers: Int) {
        guard (0...127).contains(keyCode) else { return }
        let bits = modifiers & ShortcutModifier.all
        var flags: CGEventFlags = []
        if bits & ShortcutModifier.command != 0 { flags.insert(.maskCommand) }
        if bits & ShortcutModifier.option != 0 { flags.insert(.maskAlternate) }
        if bits & ShortcutModifier.control != 0 { flags.insert(.maskControl) }
        if bits & ShortcutModifier.shift != 0 { flags.insert(.maskShift) }
        if bits & ShortcutModifier.fn != 0 { flags.insert(.maskSecondaryFn) }
        pressKey(CGKeyCode(keyCode), flags: flags)
    }

    private func type(_ text: String) {
        for character in text {
            if character == "\n" || character == "\r" || character == "\r\n" {
                pressKey(KeyCode.returnKey)
                continue
            }
            let units = Array(String(character).utf16)
            guard !units.isEmpty else { continue }
            for keyDown in [true, false] {
                guard let event = CGEvent(keyboardEventSource: source, virtualKey: 0, keyDown: keyDown) else { continue }
                event.keyboardSetUnicodeString(stringLength: units.count, unicodeString: units)
                event.flags = []
                event.post(tap: .cghidEventTap)
            }
        }
    }
}
