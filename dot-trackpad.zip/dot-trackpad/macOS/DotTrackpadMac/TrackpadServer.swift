import Foundation
import Network

/// Advertises `_dottrackpad._tcp` over Bonjour and accepts one iPhone connection at a time
/// (a new connection replaces the previous one). All state is confined to `queue`.
final class TrackpadServer {
    /// Human-readable status for the menu. May be called on any queue.
    var onStatus: ((String) -> Void)?
    /// Called on `queue` for every message received from the iPhone.
    var onMessage: ((Message) -> Void)?
    /// Called on `queue` when a phone becomes ready (true) or goes away (false).
    var onConnectionChange: ((Bool) -> Void)?

    private let queue = DispatchQueue(label: "dottrackpad.server")
    private var listener: NWListener?
    private var connection: NWConnection?
    private var decoder = FrameDecoder()
    private var started = false

    func start() {
        queue.async {
            guard !self.started else { return }
            self.started = true
            self.startListener()
        }
    }

    /// Sends a message to the connected phone (no-op if none).
    func send(_ message: Message) {
        queue.async {
            guard let connection = self.connection,
                  case .ready = connection.state,
                  let frame = FrameCodec.encode(message) else { return }
            connection.send(content: frame, completion: .contentProcessed { _ in })
        }
    }

    // MARK: Listener

    private func startListener() {
        do {
            let tcp = NWProtocolTCP.Options()
            tcp.noDelay = true
            tcp.enableKeepalive = true
            tcp.keepaliveIdle = 5
            tcp.keepaliveInterval = 2
            tcp.keepaliveCount = 3
            let parameters = NWParameters(tls: nil, tcp: tcp)

            let listener = try NWListener(using: parameters)
            let name = Host.current().localizedName ?? "Mac"
            listener.service = NWListener.Service(name: name, type: Wire.serviceType)
            self.listener = listener

            listener.stateUpdateHandler = { [weak self, weak listener] state in
                guard let self = self, let listener = listener, listener === self.listener else { return }
                switch state {
                case .ready:
                    if self.connection == nil { self.onStatus?("Waiting for iPhone…") }
                case .failed(let error):
                    self.onStatus?("Network error: \(error.localizedDescription)")
                    listener.cancel()
                    self.listener = nil
                    self.queue.asyncAfter(deadline: .now() + 2) { self.startListener() }
                default:
                    break
                }
            }
            listener.newConnectionHandler = { [weak self] newConnection in
                self?.accept(newConnection)
            }
            listener.start(queue: queue)
        } catch {
            onStatus?("Could not start: \(error.localizedDescription)")
            queue.asyncAfter(deadline: .now() + 5) { self.startListener() }
        }
    }

    // MARK: Connection

    private func accept(_ newConnection: NWConnection) {
        if let old = connection {
            connection = nil
            old.cancel()
            onConnectionChange?(false)
        }
        connection = newConnection
        decoder = FrameDecoder()

        newConnection.stateUpdateHandler = { [weak self, weak newConnection] state in
            guard let self = self, let conn = newConnection, conn === self.connection else { return }
            switch state {
            case .ready:
                self.onStatus?("Connected to iPhone")
                self.onConnectionChange?(true)
                self.receive(on: conn)
            case .failed, .cancelled:
                self.drop(conn)
            default:
                break
            }
        }
        newConnection.start(queue: queue)
    }

    private func receive(on conn: NWConnection) {
        conn.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { [weak self] data, _, isComplete, error in
            guard let self = self, conn === self.connection else { return }

            if let data = data, !data.isEmpty {
                self.decoder.append(data)
                do {
                    for message in try self.decoder.drain() {
                        self.onMessage?(message)
                    }
                } catch {
                    self.drop(conn)
                    return
                }
            }

            if error != nil || isComplete {
                self.drop(conn)
            } else {
                self.receive(on: conn)
            }
        }
    }

    private func drop(_ conn: NWConnection) {
        guard conn === connection else { return }
        conn.cancel()
        connection = nil
        decoder = FrameDecoder()
        onConnectionChange?(false)
        onStatus?("Waiting for iPhone…")
    }
}
