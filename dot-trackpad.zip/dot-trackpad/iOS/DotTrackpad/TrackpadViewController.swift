import UIKit

final class TrackpadViewController: UIViewController, UIAdaptivePresentationControllerDelegate {
    private let trackpad = TrackpadView()
    private let connection = MacConnection()
    private var macReportsTextFocus = false
    private var settingsOpen = false

    override func loadView() {
        view = trackpad
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .allButUpsideDown }

    /// Edge swipes start inside the grid, but defer the system's own left/right edge gestures anyway.
    override var preferredScreenEdgesDeferringSystemGestures: UIRectEdge { [.left, .right] }

    override func viewDidLoad() {
        super.viewDidLoad()

        trackpad.onMessage = { [weak self] message in
            self?.connection.send(message)
        }
        trackpad.onHotkey = { [weak self] hotkey in
            self?.connection.send(hotkey.message)
        }
        connection.onLevels = { [weak self] volume, brightness in
            self?.trackpad.applyLevels(volume: volume, brightness: brightness)
        }
        trackpad.onSettingsTapped = { [weak self] in
            self?.presentSettings()
        }
        connection.onFocusChange = { [weak self] focused in
            self?.macReportsTextFocus = focused
            self?.updateKeyboard()
        }
        AppCatalog.shared.requestHandler = { [weak self] in
            self?.connection.send(.requestApps)
        }

        let center = NotificationCenter.default
        center.addObserver(self, selector: #selector(appDidBecomeActive),
                           name: UIApplication.didBecomeActiveNotification, object: nil)
        center.addObserver(self, selector: #selector(appDidEnterBackground),
                           name: UIApplication.didEnterBackgroundNotification, object: nil)
        center.addObserver(self, selector: #selector(settingsChanged),
                           name: AppSettings.didChange, object: nil)
    }

    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        setNeedsUpdateOfScreenEdgesDeferringSystemGestures()
        connection.start()
        updateKeyboard()
    }

    @objc private func appDidBecomeActive() {
        connection.start()
        updateKeyboard()
    }

    @objc private func appDidEnterBackground() {
        connection.stop()
    }

    @objc private func settingsChanged() {
        updateKeyboard()
    }

    // MARK: Settings panel

    private func presentSettings() {
        guard !settingsOpen else { return }
        settingsOpen = true
        updateKeyboard()

        let settings = SettingsViewController()
        settings.onDone = { [weak self] in
            self?.dismiss(animated: true) {
                self?.settingsClosed()
            }
        }
        let navigation = UINavigationController(rootViewController: settings)
        navigation.overrideUserInterfaceStyle = .dark
        navigation.modalPresentationStyle = .pageSheet
        navigation.presentationController?.delegate = self
        if let sheet = navigation.sheetPresentationController {
            // Keep the top of the dot grid visible (and undimmed) so setting changes can be seen live.
            sheet.detents = [.medium(), .large()]
            sheet.largestUndimmedDetentIdentifier = .medium
            sheet.prefersGrabberVisible = true
        }
        present(navigation, animated: true)
    }

    func presentationControllerDidDismiss(_ presentationController: UIPresentationController) {
        settingsClosed()
    }

    private func settingsClosed() {
        settingsOpen = false
        updateKeyboard()
    }

    // MARK: Keyboard

    /// Shows the system keyboard only while the Mac reports a focused text field
    /// AND the keyboard setting (gear icon) is on, and never while the settings panel is open.
    private func updateKeyboard() {
        let wantKeyboard = macReportsTextFocus && AppSettings.keyboardEnabled && !settingsOpen
        if wantKeyboard {
            if !trackpad.isFirstResponder {
                _ = trackpad.becomeFirstResponder()
            }
        } else if trackpad.isFirstResponder {
            _ = trackpad.resignFirstResponder()
        }
    }
}
