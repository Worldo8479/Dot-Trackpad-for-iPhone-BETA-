import Foundation
import ApplicationServices

/// Polls the Accessibility API (twice a second, only while a phone is connected) and
/// reports whether the focused UI element is a text input.
final class FocusMonitor {
    /// Called on the monitor's queue when the focus state changes (and once right after activation).
    var onChange: ((Bool) -> Void)?

    private let queue = DispatchQueue(label: "dottrackpad.focus", qos: .utility)
    private var timer: DispatchSourceTimer?
    private var last: Bool?

    func setActive(_ active: Bool) {
        queue.async {
            self.timer?.cancel()
            self.timer = nil
            self.last = nil
            guard active else { return }

            let timer = DispatchSource.makeTimerSource(queue: self.queue)
            timer.schedule(deadline: .now(), repeating: .milliseconds(500), leeway: .milliseconds(100))
            timer.setEventHandler { [weak self] in self?.poll() }
            self.timer = timer
            timer.resume()
        }
    }

    private func poll() {
        let focused = Self.isTextInputFocused()
        if focused != last {
            last = focused
            onChange?(focused)
        }
    }

    // MARK: Accessibility queries

    private static let textRoles: Set<String> = ["AXTextField", "AXTextArea", "AXComboBox", "AXSearchField"]

    private static func attribute(_ element: AXUIElement, _ name: String) -> CFTypeRef? {
        var value: CFTypeRef?
        guard AXUIElementCopyAttributeValue(element, name as CFString, &value) == .success else { return nil }
        return value
    }

    private static func element(_ element: AXUIElement, _ name: String) -> AXUIElement? {
        guard let value = attribute(element, name), CFGetTypeID(value) == AXUIElementGetTypeID() else { return nil }
        return (value as! AXUIElement)
    }

    private static func focusedElement() -> AXUIElement? {
        let systemWide = AXUIElementCreateSystemWide()
        AXUIElementSetMessagingTimeout(systemWide, 0.25)
        if let focused = element(systemWide, "AXFocusedUIElement") {
            return focused
        }
        // Some apps only answer through their application element.
        if let app = element(systemWide, "AXFocusedApplication") {
            AXUIElementSetMessagingTimeout(app, 0.25)
            return element(app, "AXFocusedUIElement")
        }
        return nil
    }

    static func isTextInputFocused() -> Bool {
        guard AXIsProcessTrusted(), let focused = focusedElement() else { return false }

        if let role = attribute(focused, "AXRole") as? String, textRoles.contains(role) {
            return true
        }
        if let subrole = attribute(focused, "AXSubrole") as? String, subrole == "AXSearchField" {
            return true
        }
        // Editable content (e.g. contenteditable regions in browsers).
        if let editable = attribute(focused, "AXEditable") as? Bool, editable {
            return true
        }
        return false
    }
}
