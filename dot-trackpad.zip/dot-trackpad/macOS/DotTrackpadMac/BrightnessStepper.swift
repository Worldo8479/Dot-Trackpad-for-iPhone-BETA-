import Foundation

/// Plans brightness-key presses for the fallback path (used when the private DisplayServices
/// API is unavailable or does not support the display).
///
/// The keyboard brightness keys move the display in 16 steps, but give no feedback, so the
/// stepper keeps an *estimate* of the current level. If the level is unknown, the first plan
/// drives the display to the nearer end of the range (a known state) and then steps back to
/// the target, so the result is deterministic.
struct BrightnessStepper {
    static let steps = 16

    /// Estimated current level (0...1), nil until the first plan.
    private(set) var estimate: Double?

    /// Returns signed key-press runs to execute in order: positive = brightness-up presses,
    /// negative = brightness-down presses. Updates the estimate as if the runs were executed.
    mutating func plan(target: Double) -> [Int] {
        let clamped = target.isFinite ? min(max(target, 0), 1) : 0
        let targetStep = Int((clamped * Double(Self.steps)).rounded())

        if let current = estimate {
            let currentStep = Int((current * Double(Self.steps)).rounded())
            estimate = Double(targetStep) / Double(Self.steps)
            let diff = targetStep - currentStep
            return diff == 0 ? [] : [diff]
        }

        estimate = Double(targetStep) / Double(Self.steps)
        if targetStep >= Self.steps / 2 {
            return targetStep >= Self.steps ? [Self.steps] : [Self.steps, targetStep - Self.steps]
        } else {
            return targetStep <= 0 ? [-Self.steps] : [-Self.steps, targetStep]
        }
    }
}
