import UIKit

/// Full-screen black view with a centred grid of small dots ("cutting mat") surrounded by
/// black margins. Dots near the finger(s) grow. Touches that start inside the grid are turned
/// into trackpad messages; touches that start in the margins are ignored. The margins hold a
/// small gear icon (top right) and an optional hotkey strip (below the grid).
///
/// The view also acts as an invisible `UIKeyInput` so the system keyboard can be raised
/// without any visible text field.
final class TrackpadView: UIView, UIKeyInput {

    /// Everything the view wants to send to the Mac.
    var onMessage: ((Message) -> Void)?
    /// Gear icon tapped.
    var onSettingsTapped: (() -> Void)?
    /// A hotkey-strip button or an edge swipe fired this hotkey (open app / keyboard shortcut).
    var onHotkey: ((Hotkey) -> Void)?

    // MARK: Style (read from AppSettings, refreshed live)

    private struct Style {
        var spacing: CGFloat
        var baseRadius: CGFloat
        var peakRadius: CGFloat
        var influence: CGFloat
        var haptics: Bool
        var pointerSpeed: Double

        static func current() -> Style {
            let base = CGFloat(AppSettings.dotSize)
            return Style(spacing: CGFloat(AppSettings.dotSpacing),
                         baseRadius: base,
                         peakRadius: base + CGFloat(AppSettings.growth),
                         influence: CGFloat(AppSettings.highlightRadius),
                         haptics: AppSettings.hapticsEnabled,
                         pointerSpeed: AppSettings.pointerSpeed)
        }
    }

    private var style = Style.current()
    private static let baseAlpha: CGFloat = 0.32

    // MARK: Margin UI

    private let settingsButton = UIButton(type: .system)
    private let hotkeyStrip = UIStackView()
    private var hotkeyCount = 0

    // MARK: Quick level sliders (left edge: Mac volume, right edge: Mac brightness)

    private static let levelIdleTimeout: TimeInterval = 3
    private var levelPanel: LevelSliderView?
    private var levelPanelEdge = EdgeSwipeDetector.Edge.left
    private var levelIdleTimer: Timer?
    private var levelThrottle = LevelThrottle()
    private var knownVolume: Double?
    private var knownBrightness: Double?

    // MARK: Touch state

    private enum Mode {
        case idle
        case pointer      // one finger
        case twoFinger    // two fingers: scroll / pinch
        case ignored      // started outside the grid, 3+ fingers, fingers lifted one by one, edge swipe done
    }

    private var mode: Mode = .idle
    private var activeTouches: [UITouch] = []
    private var startLocations: [ObjectIdentifier: CGPoint] = [:]
    private var maxTouches = 0
    private var sequenceStart: TimeInterval = 0
    private var sequenceInsideGrid = false
    private var travel: CGFloat = 0
    private var edgeDetector = EdgeSwipeDetector()

    private var twoFingerDecision: TwoFingerDecision?
    private var lastCentroid = CGPoint.zero
    private var lastDistance: CGFloat = 0
    private var accumulatedMovement = 0.0
    private var accumulatedPinch = 0.0

    // MARK: Glow + haptics

    private var glowPoints: [CGPoint] = []
    private let haptics = UISelectionFeedbackGenerator()
    private var lastHapticCell: (Int, Int)?
    private var lastHapticTime: CFTimeInterval = 0
    private static let hapticMinInterval: CFTimeInterval = 0.035

    // MARK: Init

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        backgroundColor = .black
        isOpaque = true
        isMultipleTouchEnabled = true
        isExclusiveTouch = true
        contentMode = .redraw
        inputAssistantItem.leadingBarButtonGroups = []
        inputAssistantItem.trailingBarButtonGroups = []

        let symbol = UIImage.SymbolConfiguration(pointSize: 18, weight: .regular)
        settingsButton.setImage(UIImage(systemName: "gearshape", withConfiguration: symbol), for: .normal)
        settingsButton.tintColor = UIColor(white: 1, alpha: 0.4)
        settingsButton.accessibilityLabel = "Settings"
        settingsButton.addTarget(self, action: #selector(settingsTapped), for: .touchUpInside)
        addSubview(settingsButton)

        hotkeyStrip.axis = .horizontal
        hotkeyStrip.distribution = .fillEqually
        hotkeyStrip.spacing = 8
        addSubview(hotkeyStrip)
        reloadHotkeys()

        NotificationCenter.default.addObserver(self, selector: #selector(settingsDidChange),
                                               name: AppSettings.didChange, object: nil)
    }

    @objc private func settingsTapped() {
        hideLevelPanel(animated: false)
        onSettingsTapped?()
    }

    @objc private func settingsDidChange() {
        style = Style.current()
        reloadHotkeys()
        setNeedsLayout()
        setNeedsDisplay()
    }

    // MARK: Layout

    private var geometry: GridGeometry {
        GridGeometry.make(boundsWidth: Double(bounds.width), boundsHeight: Double(bounds.height),
                          safeTop: Double(safeAreaInsets.top), safeLeft: Double(safeAreaInsets.left),
                          safeBottom: Double(safeAreaInsets.bottom), safeRight: Double(safeAreaInsets.right))
    }

    private var gridRect: CGRect {
        let g = geometry
        return CGRect(x: g.x, y: g.y, width: g.width, height: g.height)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        let g = geometry
        // Gear: 44x44, in the top margin at the grid's right edge.
        settingsButton.frame = CGRect(x: g.maxX - 44, y: max(0, g.y - 44), width: 44, height: 44)
        // Hotkey strip: in the bottom margin, centred under the grid, only as wide as needed.
        let stripWidth = min(g.width, Double(hotkeyCount) * 104)
        hotkeyStrip.frame = CGRect(x: g.x + (g.width - stripWidth) / 2, y: g.maxY + 4,
                                   width: stripWidth, height: 36)
        bringSubviewToFront(settingsButton)
        bringSubviewToFront(hotkeyStrip)
        if let panel = levelPanel {
            panel.frame = levelPanelFrame(for: levelPanelEdge)
            bringSubviewToFront(panel)
        }
    }

    override func safeAreaInsetsDidChange() {
        super.safeAreaInsetsDidChange()
        setNeedsLayout()
        setNeedsDisplay()
    }

    // MARK: Hotkey strip

    private func reloadHotkeys() {
        for view in hotkeyStrip.arrangedSubviews {
            hotkeyStrip.removeArrangedSubview(view)
            view.removeFromSuperview()
        }
        var count = 0
        for slot in 0..<AppSettings.slotCount {
            guard let hotkey = AppSettings.hotkey(for: .slot(slot)) else { continue }
            let button = UIButton(type: .system)
            button.setTitle(hotkey.displayName, for: .normal)
            button.titleLabel?.font = .systemFont(ofSize: 12, weight: .medium)
            button.titleLabel?.lineBreakMode = .byTruncatingTail
            button.titleLabel?.adjustsFontSizeToFitWidth = true
            button.titleLabel?.minimumScaleFactor = 0.75
            button.tintColor = UIColor(white: 1, alpha: 0.75)
            button.layer.cornerRadius = 16
            button.layer.borderWidth = 1
            button.layer.borderColor = UIColor(white: 1, alpha: 0.25).cgColor
            button.accessibilityLabel = hotkey.displayName
            button.addAction(UIAction { [weak self] _ in
                self?.hideLevelPanel(animated: false)
                self?.onHotkey?(hotkey)
            }, for: .touchUpInside)
            hotkeyStrip.addArrangedSubview(button)
            count += 1
        }
        hotkeyCount = count
        hotkeyStrip.isHidden = count == 0
    }

    // MARK: Drawing

    private func gridMetrics() -> (cols: Int, rows: Int, offsetX: CGFloat, offsetY: CGFloat) {
        let s = style.spacing
        let area = gridRect
        let cols = max(Int(area.width / s), 0)
        let rows = max(Int(area.height / s), 0)
        let offsetX = area.minX + (area.width - CGFloat(cols) * s) / 2
        let offsetY = area.minY + (area.height - CGFloat(rows) * s) / 2
        return (cols, rows, offsetX, offsetY)
    }

    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        ctx.setFillColor(UIColor.black.cgColor)
        ctx.fill(rect)

        let st = style
        let s = st.spacing
        let m = gridMetrics()
        guard m.cols > 0, m.rows > 0 else { return }
        let reach = st.peakRadius

        let c0 = max(0, Int(floor((rect.minX - m.offsetX - reach) / s - 0.5)))
        let c1 = min(m.cols - 1, Int(ceil((rect.maxX - m.offsetX + reach) / s - 0.5)))
        let r0 = max(0, Int(floor((rect.minY - m.offsetY - reach) / s - 0.5)))
        let r1 = min(m.rows - 1, Int(ceil((rect.maxY - m.offsetY + reach) / s - 0.5)))
        guard c0 <= c1, r0 <= r1 else { return }

        for row in r0...r1 {
            for col in c0...c1 {
                let cx = m.offsetX + (CGFloat(col) + 0.5) * s
                let cy = m.offsetY + (CGFloat(row) + 0.5) * s

                var strength: CGFloat = 0
                for p in glowPoints {
                    let d = hypot(cx - p.x, cy - p.y)
                    if d < st.influence {
                        let t = 1 - d / st.influence
                        strength = max(strength, t * t)
                    }
                }

                let radius = st.baseRadius + (st.peakRadius - st.baseRadius) * strength
                let alpha = Self.baseAlpha + (1 - Self.baseAlpha) * strength
                ctx.setFillColor(gray: 1, alpha: alpha)
                ctx.fillEllipse(in: CGRect(x: cx - radius, y: cy - radius, width: radius * 2, height: radius * 2))
            }
        }
    }

    private func dirtyRect(around p: CGPoint) -> CGRect {
        let r = style.influence + style.peakRadius + 2
        return CGRect(x: p.x - r, y: p.y - r, width: r * 2, height: r * 2).intersection(bounds)
    }

    private func updateGlow(_ newPoints: [CGPoint]) {
        let old = glowPoints
        glowPoints = newPoints
        for p in old + newPoints {
            let r = dirtyRect(around: p)
            if !r.isNull && !r.isEmpty { setNeedsDisplay(r) }
        }
    }

    private func refreshGlowFromTouches() {
        updateGlow(sequenceInsideGrid ? activeTouches.map { $0.location(in: self) } : [])
    }

    // MARK: Haptics

    private func hapticTick(at point: CGPoint) {
        guard style.haptics else { return }
        let origin = gridRect.origin
        let s = style.spacing
        let cell = (Int(floor((point.x - origin.x) / s)), Int(floor((point.y - origin.y) / s)))
        if let last = lastHapticCell, last == cell { return }
        lastHapticCell = cell
        let now = CACurrentMediaTime()
        guard now - lastHapticTime >= Self.hapticMinInterval else { return }
        lastHapticTime = now
        haptics.selectionChanged()
        haptics.prepare()
    }

    // MARK: Touch handling

    private func centroid(of touches: [UITouch]) -> CGPoint {
        guard !touches.isEmpty else { return .zero }
        var x: CGFloat = 0
        var y: CGFloat = 0
        for t in touches {
            let p = t.location(in: self)
            x += p.x
            y += p.y
        }
        return CGPoint(x: x / CGFloat(touches.count), y: y / CGFloat(touches.count))
    }

    private func distanceBetweenFirstTwo() -> CGFloat {
        guard activeTouches.count >= 2 else { return 0 }
        let a = activeTouches[0].location(in: self)
        let b = activeTouches[1].location(in: self)
        return hypot(a.x - b.x, a.y - b.y)
    }

    private func beginTwoFingerTracking() {
        twoFingerDecision = nil
        accumulatedMovement = 0
        accumulatedPinch = 0
        lastCentroid = centroid(of: Array(activeTouches.prefix(2)))
        lastDistance = distanceBetweenFirstTwo()
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if activeTouches.isEmpty {
            // A new touch sequence. Only sequences that START inside the grid do anything.
            mode = .idle
            maxTouches = 0
            travel = 0
            sequenceStart = touches.first?.timestamp ?? 0
            lastHapticCell = nil
            edgeDetector.cancel()

            let first = touches.first?.location(in: self) ?? .zero
            let grid = geometry
            sequenceInsideGrid = grid.contains(x: Double(first.x), y: Double(first.y))
            if levelPanel != nil {
                // A touch anywhere but on the slider dismisses it and does nothing else.
                hideLevelPanel(animated: true)
                sequenceInsideGrid = false
            }
            if sequenceInsideGrid {
                edgeDetector.begin(x: Double(first.x), y: Double(first.y),
                                   gridMinX: grid.x, gridMaxX: grid.maxX,
                                   isAssigned: { AppSettings.edgeHotkey($0) != nil })
                haptics.prepare()
            }
        }

        for t in touches {
            activeTouches.append(t)
            startLocations[ObjectIdentifier(t)] = t.location(in: self)
        }
        maxTouches = max(maxTouches, activeTouches.count)

        if !sequenceInsideGrid {
            mode = .ignored
        } else {
            switch activeTouches.count {
            case 1:
                mode = .pointer
            case 2:
                if mode != .ignored {
                    mode = .twoFinger
                    edgeDetector.cancel()
                    beginTwoFingerTracking()
                }
            default:
                mode = .ignored
            }
        }
        refreshGlowFromTouches()
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard !activeTouches.isEmpty else { return }

        for t in activeTouches {
            if let start = startLocations[ObjectIdentifier(t)] {
                let p = t.location(in: self)
                travel = max(travel, hypot(p.x - start.x, p.y - start.y))
            }
        }

        switch mode {
        case .pointer:
            if let t = activeTouches.first, touches.contains(t) {
                handlePointerMove(t)
            }
        case .twoFinger:
            handleTwoFingerMove()
        case .idle, .ignored:
            break
        }

        refreshGlowFromTouches()
        if sequenceInsideGrid && !activeTouches.isEmpty {
            hapticTick(at: centroid(of: activeTouches))
        }
    }

    private func handlePointerMove(_ t: UITouch) {
        let cur = t.location(in: self)
        switch edgeDetector.update(x: Double(cur.x), y: Double(cur.y)) {
        case .pending:
            // Might still turn into an edge swipe: keep the cursor still for now.
            return
        case .triggered(let edge):
            mode = .ignored   // the rest of this drag does nothing
            if let hotkey = AppSettings.edgeHotkey(edge) {
                onHotkey?(hotkey)
            }
            return
        case .triggeredInward(let edge):
            mode = .ignored   // the rest of this drag does nothing
            showLevelPanel(for: edge)
            return
        case .notEdge:
            break
        }

        let prev = t.previousLocation(in: self)
        let accelerated = PointerAcceleration.apply(dx: Double(cur.x - prev.x), dy: Double(cur.y - prev.y),
                                                    speed: style.pointerSpeed)
        if accelerated.dx != 0 || accelerated.dy != 0 {
            onMessage?(.move(dx: accelerated.dx, dy: accelerated.dy))
        }
    }

    private func handleTwoFingerMove() {
        guard activeTouches.count >= 2 else { return }
        let c = centroid(of: Array(activeTouches.prefix(2)))
        let d = distanceBetweenFirstTwo()
        let dc = CGPoint(x: c.x - lastCentroid.x, y: c.y - lastCentroid.y)
        let dd = d - lastDistance
        lastCentroid = c
        lastDistance = d

        if twoFingerDecision == nil {
            accumulatedMovement += Double(hypot(dc.x, dc.y))
            accumulatedPinch += Double(abs(dd))
            twoFingerDecision = TwoFingerClassifier.decide(movement: accumulatedMovement, pinch: accumulatedPinch)
            return
        }

        switch twoFingerDecision {
        case .scroll?:
            onMessage?(.scroll(dx: Double(dc.x) * ScrollTuning.gain, dy: Double(dc.y) * ScrollTuning.gain))
        case .pinch?:
            if dd != 0 { onMessage?(.zoom(delta: Double(dd))) }
        case nil:
            break
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        let endTime = touches.first?.timestamp ?? sequenceStart
        for t in touches {
            activeTouches.removeAll { $0 === t }
            startLocations[ObjectIdentifier(t)] = nil
        }

        if activeTouches.isEmpty {
            let duration = endTime - sequenceStart
            if sequenceInsideGrid, mode != .idle,
               let click = TapRules.classify(maxTouches: maxTouches, duration: duration, travel: Double(travel)) {
                onMessage?(click)
            }
            resetSequence()
        } else {
            // Fingers lifted one at a time: ignore the rest of the sequence so the cursor never jumps.
            mode = .ignored
        }
        refreshGlowFromTouches()
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        for t in touches {
            activeTouches.removeAll { $0 === t }
            startLocations[ObjectIdentifier(t)] = nil
        }
        if activeTouches.isEmpty {
            resetSequence()
        } else {
            mode = .ignored
        }
        refreshGlowFromTouches()
    }

    private func resetSequence() {
        mode = .idle
        maxTouches = 0
        travel = 0
        twoFingerDecision = nil
        sequenceInsideGrid = false
        edgeDetector.cancel()
        startLocations.removeAll()
        lastHapticCell = nil
    }

    // MARK: Level panel

    private func levelPanelFrame(for edge: EdgeSwipeDetector.Edge) -> CGRect {
        let g = geometry
        let height = min(max(g.height * 0.6, 160), 320, g.height)
        let margin = 16.0
        let x = edge == .left ? g.x + margin : g.maxX - margin - Double(LevelSliderView.width)
        return CGRect(x: x, y: g.y + (g.height - height) / 2, width: Double(LevelSliderView.width), height: height)
    }

    private func showLevelPanel(for edge: EdgeSwipeDetector.Edge) {
        hideLevelPanel(animated: false)
        let kind: LevelSliderView.Kind = edge == .left ? .volume : .brightness
        let panel = LevelSliderView(kind: kind)
        panel.value = kind == .volume ? knownVolume : knownBrightness
        panel.onInteraction = { [weak self] in self?.restartLevelIdleTimer() }
        panel.onChange = { [weak self] value, isFinal in
            guard let self = self else { return }
            guard self.levelThrottle.shouldSend(value: value, now: CACurrentMediaTime(), isFinal: isFinal) else { return }
            self.onMessage?(kind == .volume ? .setVolume(value) : .setBrightness(value))
            if kind == .volume { self.knownVolume = value } else { self.knownBrightness = value }
        }
        levelPanelEdge = edge
        levelPanel = panel
        levelThrottle.reset()
        panel.frame = levelPanelFrame(for: edge)
        panel.alpha = 0
        addSubview(panel)
        UIView.animate(withDuration: 0.15) { panel.alpha = 1 }
        restartLevelIdleTimer()
        // Ask the Mac for the real level so the slider starts at the right place.
        onMessage?(.getLevels)
    }

    private func hideLevelPanel(animated: Bool) {
        levelIdleTimer?.invalidate()
        levelIdleTimer = nil
        guard let panel = levelPanel else { return }
        levelPanel = nil
        if animated {
            UIView.animate(withDuration: 0.15, animations: { panel.alpha = 0 }, completion: { _ in panel.removeFromSuperview() })
        } else {
            panel.removeFromSuperview()
        }
    }

    private func restartLevelIdleTimer() {
        levelIdleTimer?.invalidate()
        levelIdleTimer = Timer.scheduledTimer(withTimeInterval: Self.levelIdleTimeout, repeats: false) { [weak self] _ in
            guard let self = self else { return }
            if self.levelPanel?.isDragging == true {
                self.restartLevelIdleTimer()   // finger still down: not idle
            } else {
                self.hideLevelPanel(animated: true)
            }
        }
    }

    /// The Mac reported its current levels (nil = unknown / unsupported, e.g. brightness on some external displays).
    func applyLevels(volume: Double?, brightness: Double?) {
        if let volume = volume { knownVolume = min(max(volume, 0), 1) }
        if let brightness = brightness { knownBrightness = min(max(brightness, 0), 1) }
        guard let panel = levelPanel, !panel.isDragging else { return }
        panel.value = panel.kind == .volume ? knownVolume : knownBrightness
    }

    // MARK: UIKeyInput (invisible keyboard target)

    override var canBecomeFirstResponder: Bool { true }

    var hasText: Bool { true }

    func insertText(_ text: String) {
        if text == "\n" {
            onMessage?(.key(.returnKey))
        } else {
            onMessage?(.text(text))
        }
    }

    func deleteBackward() {
        onMessage?(.key(.backspace))
    }

    var autocorrectionType: UITextAutocorrectionType = .no
    var autocapitalizationType: UITextAutocapitalizationType = .none
    var spellCheckingType: UITextSpellCheckingType = .no
    var smartQuotesType: UITextSmartQuotesType = .no
    var smartDashesType: UITextSmartDashesType = .no
    var smartInsertDeleteType: UITextSmartInsertDeleteType = .no
    var keyboardType: UIKeyboardType = .default
    var returnKeyType: UIReturnKeyType = .default
}
