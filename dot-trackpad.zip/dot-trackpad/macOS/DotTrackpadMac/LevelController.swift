import Foundation
import AppKit
import CoreAudio
import CoreGraphics

/// Reads and sets the Mac's output volume and display brightness. Call on the main thread only.
///
/// **Volume** – CoreAudio: the default output device's virtual main volume (`'vmvc'`, a 0...1 float).
/// If the device has no settable virtual volume, AppleScript (`set volume output volume N`) is used.
///
/// **Brightness** – the private DisplayServices framework, loaded with `dlopen`/`dlsym`
/// (`DisplayServicesGetBrightness` / `DisplayServicesSetBrightness`), on the built-in display (or the
/// main display if there is no built-in one). Built-in displays (and Apple displays) are supported;
/// many external monitors are not. If those calls are missing or fail, it falls back to posting the
/// system brightness-up / -down media keys (NX_KEYTYPE_BRIGHTNESS_UP/DOWN) to step toward the target
/// (see `BrightnessStepper`); that needs the Accessibility permission the app already asks for and
/// works from an estimated level.
final class LevelController {
    // MARK: Volume

    func currentVolume() -> Double? {
        if let device = defaultOutputDevice() {
            var address = Self.volumeAddress
            if AudioObjectHasProperty(device, &address) {
                var value = Float32(0)
                var size = UInt32(MemoryLayout<Float32>.size)
                if AudioObjectGetPropertyData(device, &address, 0, nil, &size, &value) == noErr {
                    return Double(min(max(value, 0), 1))
                }
            }
        }
        if let text = runAppleScript("output volume of (get volume settings)")?.stringValue, let percent = Int(text) {
            return Double(percent) / 100
        }
        return nil
    }

    func setVolume(_ value: Double) {
        guard value.isFinite else { return }
        let level = min(max(value, 0), 1)
        if let device = defaultOutputDevice() {
            var address = Self.volumeAddress
            var settable = DarwinBoolean(false)
            if AudioObjectHasProperty(device, &address),
               AudioObjectIsPropertySettable(device, &address, &settable) == noErr, settable.boolValue {
                var scalar = Float32(level)
                let status = AudioObjectSetPropertyData(device, &address, 0, nil,
                                                        UInt32(MemoryLayout<Float32>.size), &scalar)
                if status == noErr { return }
            }
        }
        _ = runAppleScript("set volume output volume \(Int((level * 100).rounded()))")
    }

    private static let volumeFourCC: AudioObjectPropertySelector = 0x766D7663 // 'vmvc' = virtual main volume

    private static var volumeAddress: AudioObjectPropertyAddress {
        AudioObjectPropertyAddress(mSelector: volumeFourCC,
                                   mScope: kAudioDevicePropertyScopeOutput,
                                   mElement: kAudioObjectPropertyElementMain)
    }

    private func defaultOutputDevice() -> AudioDeviceID? {
        var address = AudioObjectPropertyAddress(mSelector: kAudioHardwarePropertyDefaultOutputDevice,
                                                 mScope: kAudioObjectPropertyScopeGlobal,
                                                 mElement: kAudioObjectPropertyElementMain)
        var device = AudioDeviceID(0)
        var size = UInt32(MemoryLayout<AudioDeviceID>.size)
        let status = AudioObjectGetPropertyData(AudioObjectID(kAudioObjectSystemObject), &address, 0, nil, &size, &device)
        return (status == noErr && device != 0) ? device : nil
    }

    private func runAppleScript(_ source: String) -> NSAppleScriptDescriptor? {
        var error: NSDictionary?
        return NSAppleScript(source: source)?.executeAndReturnError(&error)
    }

    // MARK: Brightness

    private typealias DisplayServicesGet = @convention(c) (CGDirectDisplayID, UnsafeMutablePointer<Float>) -> Int32
    private typealias DisplayServicesSet = @convention(c) (CGDirectDisplayID, Float) -> Int32

    private var getBrightness: DisplayServicesGet?
    private var setBrightnessFn: DisplayServicesSet?
    private var stepper = BrightnessStepper()

    init() {
        let path = "/System/Library/PrivateFrameworks/DisplayServices.framework/DisplayServices"
        if let handle = dlopen(path, RTLD_LAZY),
           let get = dlsym(handle, "DisplayServicesGetBrightness"),
           let set = dlsym(handle, "DisplayServicesSetBrightness") {
            getBrightness = unsafeBitCast(get, to: DisplayServicesGet.self)
            setBrightnessFn = unsafeBitCast(set, to: DisplayServicesSet.self)
        }
    }

    func currentBrightness() -> Double? {
        if let get = getBrightness {
            var value = Float(0)
            if get(targetDisplay(), &value) == 0 {
                return Double(min(max(value, 0), 1))
            }
        }
        return stepper.estimate
    }

    func setBrightness(_ value: Double) {
        guard value.isFinite else { return }
        let level = min(max(value, 0), 1)
        if let set = setBrightnessFn, set(targetDisplay(), Float(level)) == 0 {
            return
        }
        // Fallback: brightness keys, 16 steps, from the estimated level.
        for run in stepper.plan(target: level) {
            for _ in 0..<abs(run) {
                postBrightnessKey(up: run > 0)
            }
        }
    }

    /// The built-in display if there is one, otherwise the main display.
    private func targetDisplay() -> CGDirectDisplayID {
        var ids = [CGDirectDisplayID](repeating: 0, count: 16)
        var count: UInt32 = 0
        if CGGetActiveDisplayList(UInt32(ids.count), &ids, &count) == .success {
            for id in ids.prefix(Int(count)) where CGDisplayIsBuiltin(id) != 0 {
                return id
            }
        }
        return CGMainDisplayID()
    }

    /// Posts a system-defined media key press (down + up). NX_KEYTYPE_BRIGHTNESS_UP = 2, _DOWN = 3.
    private func postBrightnessKey(up: Bool) {
        let keyCode = up ? 2 : 3
        for isDown in [true, false] {
            let state = isDown ? 0xA : 0xB
            let event = NSEvent.otherEvent(with: .systemDefined,
                                           location: .zero,
                                           modifierFlags: NSEvent.ModifierFlags(rawValue: UInt(state << 8)),
                                           timestamp: 0,
                                           windowNumber: 0,
                                           context: nil,
                                           subtype: 8,
                                           data1: (keyCode << 16) | (state << 8),
                                           data2: -1)
            event?.cgEvent?.post(tap: .cghidEventTap)
        }
    }
}
