import Foundation

// MARK: - Shared wire protocol
//
// This file is intentionally IDENTICAL in the iOS and macOS targets
// (iOS/DotTrackpad/Protocol.swift and macOS/DotTrackpadMac/Protocol.swift).
// If you change one, change the other.
//
// Framing: every message is a 4-byte big-endian length followed by that many
// bytes of UTF-8 JSON (one `Message`), sent over a single TCP connection.

enum Wire {
    /// Bonjour service type advertised by the Mac and browsed for by the iPhone.
    static let serviceType = "_dottrackpad._tcp"
    /// Upper bound for one frame body. Larger frames are treated as corrupt.
    static let maxFrameSize = 256 * 1024
}

/// Modifier bits carried in `Message.modifiers` (wire format, independent of any OS flag values).
enum ShortcutModifier {
    static let command = 1 << 0
    static let option  = 1 << 1
    static let control = 1 << 2
    static let shift   = 1 << 3
    static let fn      = 1 << 4
    static let all     = command | option | control | shift | fn
}

/// A Mac application: display name plus bundle identifier.
struct AppInfo: Codable, Equatable {
    var name: String
    var bundleId: String
}

struct Message: Codable, Equatable {
    enum Kind: String, Codable {
        case move        // iPhone -> Mac: relative cursor move (dx, dy) in points
        case click       // iPhone -> Mac: left click
        case rightClick  // iPhone -> Mac: right click
        case scroll      // iPhone -> Mac: scroll by (dx, dy) pixels, content follows fingers
        case zoom        // iPhone -> Mac: pinch delta in points (positive = fingers spreading)
        case text        // iPhone -> Mac: typed text
        case key         // iPhone -> Mac: special key (backspace / return)
        case focus       // Mac -> iPhone: a text field is (or is not) focused
        case requestApps // iPhone -> Mac: please send the list of installed apps
        case appList     // Mac -> iPhone: installed apps (name + bundle id), in `apps`
        case openApp     // iPhone -> Mac: open / activate the app with `bundleId`
        case getLevels   // iPhone -> Mac: please send the current volume and brightness
        case levels      // Mac -> iPhone: current `volume` / `brightness` (0...1; a field is absent if unknown)
        case setVolume   // iPhone -> Mac: set the output volume to `volume` (0...1)
        case setBrightness // iPhone -> Mac: set the display brightness to `brightness` (0...1)
        case keyShortcut // iPhone -> Mac: press a key with modifiers: `keyCode` (macOS virtual key code) + `modifiers` (ShortcutModifier bits)
    }

    enum Key: String, Codable {
        case backspace
        case returnKey = "return"
    }

    var kind: Kind
    var dx: Double?
    var dy: Double?
    var text: String?
    var key: Key?
    var focused: Bool?
    var apps: [AppInfo]?
    var bundleId: String?
    var volume: Double?
    var brightness: Double?
    var keyCode: Int?
    var modifiers: Int?

    static func move(dx: Double, dy: Double) -> Message { Message(kind: .move, dx: dx, dy: dy) }
    static func scroll(dx: Double, dy: Double) -> Message { Message(kind: .scroll, dx: dx, dy: dy) }
    static func zoom(delta: Double) -> Message { Message(kind: .zoom, dx: delta) }
    static func text(_ string: String) -> Message { Message(kind: .text, text: string) }
    static func key(_ key: Key) -> Message { Message(kind: .key, key: key) }
    static func focus(_ focused: Bool) -> Message { Message(kind: .focus, focused: focused) }
    static func appList(_ apps: [AppInfo]) -> Message { Message(kind: .appList, apps: apps) }
    static func openApp(bundleId: String) -> Message { Message(kind: .openApp, bundleId: bundleId) }
    static func levels(volume: Double?, brightness: Double?) -> Message {
        Message(kind: .levels, volume: volume, brightness: brightness)
    }
    static func setVolume(_ value: Double) -> Message { Message(kind: .setVolume, volume: value) }
    static func setBrightness(_ value: Double) -> Message { Message(kind: .setBrightness, brightness: value) }
    static func keyShortcut(keyCode: Int, modifiers: Int) -> Message {
        Message(kind: .keyShortcut, keyCode: keyCode, modifiers: modifiers)
    }
    static let getLevels = Message(kind: .getLevels)
    static let requestApps = Message(kind: .requestApps)
    static let click = Message(kind: .click)
    static let rightClick = Message(kind: .rightClick)
}

enum FrameCodec {
    /// Encodes a message as `[length (UInt32, big-endian)] [JSON body]`.
    static func encode(_ message: Message) -> Data? {
        guard let body = try? JSONEncoder().encode(message),
              body.count <= Wire.maxFrameSize else { return nil }
        let n = UInt32(body.count)
        var frame = Data([
            UInt8((n >> 24) & 0xFF),
            UInt8((n >> 16) & 0xFF),
            UInt8((n >> 8) & 0xFF),
            UInt8(n & 0xFF),
        ])
        frame.append(body)
        return frame
    }
}

/// Incremental decoder: feed it bytes as they arrive from the socket, then
/// call `drain()` to get every complete message received so far.
struct FrameDecoder {
    enum DecodeError: Error {
        case frameTooLarge
        case malformed
    }

    private var buffer: [UInt8] = []

    mutating func append(_ data: Data) {
        buffer.append(contentsOf: data)
    }

    mutating func next() throws -> Message? {
        guard buffer.count >= 4 else { return nil }
        let length = (Int(buffer[0]) << 24) | (Int(buffer[1]) << 16) | (Int(buffer[2]) << 8) | Int(buffer[3])
        guard length <= Wire.maxFrameSize else { throw DecodeError.frameTooLarge }
        guard buffer.count >= 4 + length else { return nil }
        let body = Data(buffer[4..<(4 + length)])
        buffer.removeFirst(4 + length)
        do {
            return try JSONDecoder().decode(Message.self, from: body)
        } catch {
            throw DecodeError.malformed
        }
    }

    mutating func drain() throws -> [Message] {
        var out: [Message] = []
        while let message = try next() {
            out.append(message)
        }
        return out
    }
}
