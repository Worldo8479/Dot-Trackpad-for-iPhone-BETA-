import UIKit

/// A minimal dark vertical slider (top = 1, bottom = 0) used for the quick Mac volume / brightness
/// controls. Tap anywhere on it, or drag, to set the value.
final class LevelSliderView: UIView {
    enum Kind {
        case volume
        case brightness
    }

    static let width: CGFloat = 56

    let kind: Kind

    /// Current level 0...1, or nil while the Mac has not reported it yet.
    var value: Double? {
        didSet { setNeedsDisplay() }
    }

    /// Called while the finger is down (`isFinal == false`) and once when it lifts (`isFinal == true`).
    var onChange: ((Double, Bool) -> Void)?
    /// Called on any touch so the owner can restart its idle timeout.
    var onInteraction: (() -> Void)?

    private(set) var isDragging = false
    private let iconView = UIImageView()
    private static let inset: CGFloat = 14

    init(kind: Kind) {
        self.kind = kind
        super.init(frame: .zero)
        backgroundColor = .clear
        isOpaque = false
        isMultipleTouchEnabled = false
        layer.cornerRadius = Self.width / 2
        layer.masksToBounds = true
        layer.borderWidth = 1
        layer.borderColor = UIColor(white: 1, alpha: 0.25).cgColor

        let name = kind == .volume ? "speaker.wave.2.fill" : "sun.max.fill"
        iconView.image = UIImage(systemName: name, withConfiguration: UIImage.SymbolConfiguration(pointSize: 16, weight: .regular))
        iconView.tintColor = UIColor(white: 0.5, alpha: 1)
        iconView.contentMode = .center
        addSubview(iconView)
        accessibilityLabel = kind == .volume ? "Mac volume" : "Mac brightness"
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        iconView.frame = CGRect(x: 0, y: bounds.height - 40, width: bounds.width, height: 32)
    }

    override func draw(_ rect: CGRect) {
        guard let ctx = UIGraphicsGetCurrentContext() else { return }
        ctx.setFillColor(gray: 1, alpha: 0.10)
        ctx.fill(bounds)
        if let value = value {
            let fillHeight = bounds.height * CGFloat(min(max(value, 0), 1))
            ctx.setFillColor(gray: 1, alpha: 0.85)
            ctx.fill(CGRect(x: 0, y: bounds.height - fillHeight, width: bounds.width, height: fillHeight))
        }
    }

    // MARK: Touches

    private func level(for touch: UITouch) -> Double {
        LevelMapping.value(forY: Double(touch.location(in: self).y), height: Double(bounds.height), inset: Double(Self.inset))
    }

    private func apply(_ touch: UITouch, isFinal: Bool) {
        let newValue = level(for: touch)
        value = newValue
        onChange?(newValue, isFinal)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        isDragging = true
        onInteraction?()
        apply(touch, isFinal: false)
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        onInteraction?()
        apply(touch, isFinal: false)
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        isDragging = false
        onInteraction?()
        apply(touch, isFinal: true)
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        isDragging = false
        onInteraction?()
        if let value = value { onChange?(value, true) }
    }
}
