import Foundation

// Hotkey model shared by the hotkey strip slots and the edge-swipe assignments.
// Foundation only, so it can be compiled and tested off-device.

/// One key a shortcut can use: macOS virtual key code (ANSI layout) plus how it is shown.
struct KeyDef: Equatable {
    let code: Int
    let glyph: String   // as drawn in a shortcut, e.g. "A", "↩", "F5"
    let label: String   // as listed in the picker, e.g. "A", "Return", "F5"
    let group: String
}

enum KeyCatalog {
    static let groupOrder = ["Letters", "Digits", "Punctuation", "Arrows", "Special", "Function"]

    static let all: [KeyDef] = {
        var keys: [KeyDef] = []
        let letters: [(String, Int)] = [
            ("A", 0), ("B", 11), ("C", 8), ("D", 2), ("E", 14), ("F", 3), ("G", 5), ("H", 4), ("I", 34),
            ("J", 38), ("K", 40), ("L", 37), ("M", 46), ("N", 45), ("O", 31), ("P", 35), ("Q", 12),
            ("R", 15), ("S", 1), ("T", 17), ("U", 32), ("V", 9), ("W", 13), ("X", 7), ("Y", 16), ("Z", 6),
        ]
        for (name, code) in letters { keys.append(KeyDef(code: code, glyph: name, label: name, group: "Letters")) }

        let digits: [(String, Int)] = [
            ("1", 18), ("2", 19), ("3", 20), ("4", 21), ("5", 23), ("6", 22), ("7", 26), ("8", 28), ("9", 25), ("0", 29),
        ]
        for (name, code) in digits { keys.append(KeyDef(code: code, glyph: name, label: name, group: "Digits")) }

        let punctuation: [(String, Int, String)] = [
            ("-", 27, "Minus  -"), ("=", 24, "Equals  ="), ("[", 33, "Left bracket  ["), ("]", 30, "Right bracket  ]"),
            ("\\", 42, "Backslash  \\"), (";", 41, "Semicolon  ;"), ("'", 39, "Quote  '"),
            (",", 43, "Comma  ,"), (".", 47, "Period  ."), ("/", 44, "Slash  /"), ("`", 50, "Backtick  `"),
        ]
        for (glyph, code, label) in punctuation { keys.append(KeyDef(code: code, glyph: glyph, label: label, group: "Punctuation")) }

        keys.append(KeyDef(code: 123, glyph: "←", label: "Left arrow", group: "Arrows"))
        keys.append(KeyDef(code: 124, glyph: "→", label: "Right arrow", group: "Arrows"))
        keys.append(KeyDef(code: 126, glyph: "↑", label: "Up arrow", group: "Arrows"))
        keys.append(KeyDef(code: 125, glyph: "↓", label: "Down arrow", group: "Arrows"))

        keys.append(KeyDef(code: 36, glyph: "↩", label: "Return", group: "Special"))
        keys.append(KeyDef(code: 48, glyph: "⇥", label: "Tab", group: "Special"))
        keys.append(KeyDef(code: 53, glyph: "⎋", label: "Esc", group: "Special"))
        keys.append(KeyDef(code: 49, glyph: "Space", label: "Space", group: "Special"))
        keys.append(KeyDef(code: 51, glyph: "⌫", label: "Delete", group: "Special"))

        let function: [Int] = [122, 120, 99, 118, 96, 97, 98, 100, 101, 109, 103, 111]
        for (index, code) in function.enumerated() {
            keys.append(KeyDef(code: code, glyph: "F\(index + 1)", label: "F\(index + 1)", group: "Function"))
        }
        return keys
    }()

    private static let byCode: [Int: KeyDef] = Dictionary(uniqueKeysWithValues: all.map { ($0.code, $0) })

    static func key(forCode code: Int) -> KeyDef? { byCode[code] }

    static func keys(inGroup group: String) -> [KeyDef] { all.filter { $0.group == group } }
}

/// A key plus modifiers, in wire format (`ShortcutModifier` bits).
struct Shortcut: Codable, Equatable {
    var keyCode: Int
    var modifiers: Int

    var isValid: Bool {
        KeyCatalog.key(forCode: keyCode) != nil && modifiers & ~ShortcutModifier.all == 0
    }

    /// Mac-style rendering, e.g. "⌃⌥⇧⌘4", with "fn" in front when the Fn modifier is set.
    var glyphs: String {
        var text = ""
        if modifiers & ShortcutModifier.fn != 0 { text += "fn " }
        if modifiers & ShortcutModifier.control != 0 { text += "⌃" }
        if modifiers & ShortcutModifier.option != 0 { text += "⌥" }
        if modifiers & ShortcutModifier.shift != 0 { text += "⇧" }
        if modifiers & ShortcutModifier.command != 0 { text += "⌘" }
        text += KeyCatalog.key(forCode: keyCode)?.glyph ?? "?"
        return text
    }

    var message: Message { .keyShortcut(keyCode: keyCode, modifiers: modifiers) }
}

/// What a hotkey does when it is tapped (hotkey strip) or swiped (edge).
enum HotkeyAction: Equatable {
    case app(AppInfo)
    case shortcut(Shortcut)
}

extension HotkeyAction: Codable {
    private enum CodingKeys: String, CodingKey { case type, app, shortcut }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        switch try c.decode(String.self, forKey: .type) {
        case "app":
            self = .app(try c.decode(AppInfo.self, forKey: .app))
        case "shortcut":
            self = .shortcut(try c.decode(Shortcut.self, forKey: .shortcut))
        default:
            throw DecodingError.dataCorruptedError(forKey: .type, in: c, debugDescription: "unknown hotkey action type")
        }
    }

    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        switch self {
        case .app(let app):
            try c.encode("app", forKey: .type)
            try c.encode(app, forKey: .app)
        case .shortcut(let shortcut):
            try c.encode("shortcut", forKey: .type)
            try c.encode(shortcut, forKey: .shortcut)
        }
    }
}

/// A configured hotkey: an action plus an optional user-chosen name.
struct Hotkey: Codable, Equatable {
    static let maxNameLength = 24

    var name: String?
    var action: HotkeyAction

    init(name: String? = nil, action: HotkeyAction) {
        self.name = name
        self.action = action
    }

    /// The name with whitespace trimmed and length limited; nil when blank (= use the default name).
    static func cleanedName(_ raw: String?) -> String? {
        guard let raw = raw else { return nil }
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return String(trimmed.prefix(maxNameLength))
    }

    /// Name of the app, or the shortcut glyphs.
    var defaultName: String {
        switch action {
        case .app(let app): return app.name
        case .shortcut(let shortcut): return shortcut.glyphs
        }
    }

    /// What the strip button shows: the custom name if set, else the default.
    var displayName: String { Hotkey.cleanedName(name) ?? defaultName }

    var isValid: Bool {
        switch action {
        case .app(let app): return !app.bundleId.isEmpty
        case .shortcut(let shortcut): return shortcut.isValid
        }
    }

    /// Short description of the action for lists ("Open app" / the glyphs).
    var summary: String {
        switch action {
        case .app(let app): return "Open \(app.name)"
        case .shortcut(let shortcut): return "Shortcut \(shortcut.glyphs)"
        }
    }

    /// The message to send to the Mac when this hotkey fires.
    var message: Message {
        switch action {
        case .app(let app): return .openApp(bundleId: app.bundleId)
        case .shortcut(let shortcut): return shortcut.message
        }
    }
}
