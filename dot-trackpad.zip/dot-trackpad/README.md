# Dot Trackpad

Turn an iPhone into a wireless trackpad for a Mac, over your local network.

* **iPhone app** (`iOS/DotTrackpad.xcodeproj`) – a black screen with a centred grid of small dots, like a cutting mat, surrounded by black margins. Dots near your finger grow slightly and the phone ticks with a light haptic as your finger moves over dots. The only chrome is a small dim **gear icon** (top-right margin) that opens the settings panel, and an optional **hotkey strip** (bottom margin) that appears only once you assign apps to it.
* **Mac app** (`macOS/DotTrackpadMac.xcodeproj`) – a menu-bar app (no Dock icon). It advertises itself over Bonjour, accepts the phone's connection and performs the mouse, scroll, zoom, keyboard and open-app actions. The menu shows the connection status, the Accessibility permission status, and **Quit**.

## Changelog

**v1.3 (this version)**
* **Quick Mac volume / brightness sliders:** swipe *inward* (toward the centre) from the left border of the dot grid for a vertical **volume** slider on the left, or from the right border for a vertical **brightness** slider on the right. They work whether or not an app is assigned to that edge; the existing drag-down edge swipes, hotkeys and all other gestures are unchanged. Sliders dismiss after 3 s without touching them, or on a tap anywhere else. On show the phone asks the Mac for the real level.
* **Hotkeys can be keyboard shortcuts:** every hotkey slot (and edge-swipe assignment) now has an action type, *Open app* or *Keyboard shortcut* (⌃⌥⇧⌘ and optional Fn + a key, shown Mac-style, e.g. ⇧⌘4). Tapping it sends the key code + modifier flags and the Mac posts it with CGEvent.
* **Hotkeys can be renamed and changed at any time:** each slot has an editable name (shown on its strip button; default = app name or shortcut glyphs); in the slot editor you can change the action, pick another app/key, or clear it. Existing saved hotkeys are migrated automatically.
* Protocol (identical in both `Protocol.swift`): new messages `getLevels`, `levels`, `setVolume`, `setBrightness`, `keyShortcut`.
* Files added – iOS: `LevelSliderView.swift`, `Hotkey.swift`, `HotkeyEditorViewController.swift`, `KeyPickerViewController.swift`; macOS: `LevelController.swift`, `BrightnessStepper.swift`. Modified – iOS: `TrackpadView`, `TrackpadViewController`, `MacConnection`, `GestureLogic` (`EdgeSwipeDetector` now also reports inward swipes; `LevelMapping`, `LevelThrottle`), `Settings` (hotkey storage + migration), `SettingsViewController`, `AppPickerViewController` (now returns its choice to the caller), `Protocol`; macOS: `AppModel`, `InputInjector`, `Protocol`. Both `.xcodeproj` files updated.

**v1.2**
* Dot grid is now centred with visible margins on all sides; only touches that start inside the grid do anything; edge-swipe start zones are measured from the grid edge.
* Settings panel (gear icon): dot spacing, dot size, growth, highlight radius, haptics on/off, pointer speed, keyboard toggle – all stored in UserDefaults, grid redraws live.
* Hotkey strip: 6 assignable slots in the bottom margin; each opens/activates a Mac app. App list comes from the Mac (`requestApps` / `appList`).
* Edge swipes: drag down from the inside left or right edge of the grid to open an assigned app.
* Protocol: new messages `requestApps`, `appList`, `openApp` (identical `Protocol.swift` in both targets; max frame raised to 256 KB).
* Files added – iOS: `AppCatalog.swift`, `AppPickerViewController.swift`; macOS: `AppScanner.swift`. Modified – iOS: `TrackpadView.swift`, `TrackpadViewController.swift`, `SettingsViewController.swift` (now a full settings table), `Settings.swift`, `GestureLogic.swift`, `MacConnection.swift`, `Protocol.swift`; macOS: `AppModel.swift`, `InputInjector.swift`, `Protocol.swift`. Both `.xcodeproj` files updated.

**v1.1** – gear icon + keyboard toggle panel (replaced the Settings.bundle). **v1.0** – initial release.

## Minimum versions

| App | Minimum OS | Tools |
|-----|-----------|-------|
| iPhone | **iOS 16.0** (iPhone only) | Xcode 14+ (design target: Xcode 15/16) |
| Mac | **macOS 13.0** (uses `MenuBarExtra`) | Xcode 14+ |

## Build and run

You need a Mac with Xcode, an iPhone, and both devices on the **same Wi-Fi / local network** (client isolation / guest networks block discovery).

### 1. Mac app

1. Open `macOS/DotTrackpadMac.xcodeproj` in Xcode.
2. Select the **DotTrackpadMac** target → *Signing & Capabilities*. Either choose your **Team** (recommended – see note below) or leave the default "Sign to Run Locally".
3. Change the bundle identifier (`com.example.DotTrackpadMac`) if Xcode asks you to.
4. Run (⌘R). A dotted-grid icon appears in the menu bar.
5. macOS asks for **Accessibility** access: click *Open System Settings* and enable **DotTrackpadMac** in *Privacy & Security → Accessibility*. The menu shows "Accessibility: allowed" once granted (it refreshes every 2 s). Without it the Mac cannot move the cursor, click, type or detect text fields. (Opening apps from the hotkey strip / edge swipes does **not** need Accessibility.)
6. If macOS asks about the local network, allow it.

> macOS ties the Accessibility grant to the app's code signature. Builds signed with a real Team keep the grant across rebuilds; ad-hoc ("Sign to Run Locally") builds may need the entry re-enabled (remove with "–", re-add) after rebuilding.

The app is **not sandboxed** (App Sandbox is off) because posting CGEvents and scanning `/Applications` need it. It cannot be distributed on the Mac App Store as is.

### 2. iPhone app

1. Open `iOS/DotTrackpad.xcodeproj` in Xcode.
2. Select the **DotTrackpad** target → *Signing & Capabilities* → choose your **Team** and, if needed, change the bundle identifier (`com.example.DotTrackpad`).
3. Plug in the iPhone (enable Developer Mode if prompted), select it as the run destination and run (⌘R). (The Simulator works for discovery but has no haptics or real multi-touch.)
4. On first launch iOS asks to allow **Local Network** access – tap **Allow**. (If you tapped Don't Allow: *Settings → Dot Trackpad → Local Network*.)
5. With the Mac app running, the phone finds it automatically (Bonjour, no IP entry). The Mac menu changes to "Connected to iPhone". There is deliberately no on-screen connection indicator on the phone; it reconnects automatically if the Mac or Wi-Fi drops.

### XcodeGen fallback

`brew install xcodegen`, then run `xcodegen generate` inside `iOS/` and inside `macOS/` (each has a `project.yml`; sources are picked up from the folders automatically). The committed `.xcodeproj` files are the primary projects.

## Screen layout (iPhone)

```
┌───────────────────────────┐
│                      ⚙︎   │  ← top margin: gear icon (opens Settings)
│  ┌─────────────────────┐  │
│  │ · · · · · · · · · · │  │
│  │ · · · dot grid · · ·│  │  ← centred; only touches that START here are used
│  │ · · · · · · · · · · │  │     (left/right 28 pt strips = edge-swipe start zones)
│  └─────────────────────┘  │
│   [ Safari ][ Mail ][ … ] │  ← bottom margin: hotkey strip (assigned slots only)
└───────────────────────────┘
```

The grid is exactly centred: margins are ≥ 44 pt above/below (plus the larger of the top/bottom safe-area insets) and ≥ 20 pt left/right (plus the larger side safe-area inset). A touch (or two-finger gesture) that **starts in a margin is ignored** and never moves the cursor. Once a drag has started inside the grid it keeps working even if the finger wanders out of it (movement is relative).

## Gesture mapping

| Gesture (starting inside the grid) | Result on the Mac |
|-----------------------|-------------------|
| One-finger drag | Move cursor (relative; 1.6× base gain × *Pointer speed* setting, with up to 3× speed-based acceleration) |
| One-finger tap | Left click (quick taps in the same spot become double/triple clicks) |
| Two-finger drag | Scroll (vertical and horizontal; content follows your fingers, like iOS) |
| Two-finger tap | Right click |
| Pinch (spread / squeeze) | Zoom in / out, sent as **⌘ + `=`** / **⌘ + `-`** key presses (one step per ~30 pt of pinch travel) |
| **Drag down from the inside left / right edge of the grid** | Run the hotkey (app or keyboard shortcut) assigned to that edge (see below) |
| **Swipe inward from the left border of the grid** (start in the left edge zone, move right) | Show the Mac **volume** slider on the left |
| **Swipe inward from the right border of the grid** (start in the right edge zone, move left) | Show the Mac **brightness** slider on the right |
| Drag / tap on a shown slider | Set the Mac level. Tap elsewhere, or 3 s idle, dismisses it |
| Tap a button in the hotkey strip (bottom margin) | Run that slot's hotkey: open / activate its app, or press its keyboard shortcut |
| Tap the gear (top margin) | Open settings |
| Three or more fingers | Ignored |

Two-finger motion is classified once it passes ~8 pt: mostly-parallel movement = scroll, mostly-changing finger distance = pinch (the choice holds until the fingers lift). A tap is a touch shorter than 0.3 s (0.45 s for two fingers) that moves less than 10 pt. Zoom uses ⌘+/⌘− because posting real trackpad magnify gestures is not possible with public CGEvent APIs; ⌘+/⌘− zooms Safari, Chrome, Preview, most editors, Maps etc.

### Edge swipes (down = hotkey, inward = volume / brightness)

All three start in the same **28 pt zone just inside the grid's left or right border** (measured from the grid edge, not the screen edge; the screen's own left/right edge gestures are additionally deferred). What happens depends on where the finger goes:

| Finger motion from the zone | Result |
|---|---|
| **Down**: ≥ 70 pt downward, at least 2× the sideways travel (only if the edge has a hotkey assigned) | Runs the edge's hotkey (open app or keyboard shortcut) |
| **Inward**: ≥ 36 pt toward the grid centre, at least 2× the vertical travel (works whether or not a hotkey is assigned) | Left border: **volume** slider. Right border: **brightness** slider |
| Anything else (outward, upward, a diagonal that is neither mostly down nor mostly inward) | Ordinary cursor drag |

Each fires once per touch; the rest of that drag does nothing. A plain tap in the zone is still a click.

**Tradeoff (please read):** because a *mostly-horizontal inward* drag from the border now means "slider", a cursor drag that begins in the 28 pt edge strips and heads inward (or, if that edge has a hotkey, straight down) is held still while the app decides and then opens the slider (or hotkey) instead. Ordinary drags are unaffected if they start further in, or move diagonally / outward / upward, or (for the downward case) when no hotkey is assigned to that edge: the first few points of such a drag (up to ~14 pt of vertical drift, or ~24 pt for an assigned edge) are not sent to the Mac, then the cursor follows normally. A drag that wanders sideways from the strip by more than 12 pt toward the border is released at once. In practice: **start cursor drags a thumb-width in from the border** and the sliders and edge hotkeys never get in the way.

### Quick Mac volume / brightness sliders

* A minimal dark vertical slider appears inside the grid, vertically centred (volume on the left, brightness on the right). Top = 100 %, bottom = 0 %. Tap anywhere on it or drag to set the level; while you drag, values are throttled to ≤ ~20 messages per second and the final value is always sent.
* When it appears the phone sends `getLevels` and the Mac answers with `levels(volume, brightness)`, so the slider starts at the real value (it is empty for a moment if the Mac has not answered yet, and stays empty if the Mac cannot read that level).
* Dismissed after 3 s without touching it, or by touching anywhere outside it (that touch does nothing else), or by opening settings / a hotkey.
* **How the Mac sets the levels** (`LevelController.swift`):
  * **Volume** – CoreAudio: the default output device's *virtual main volume* property (`'vmvc'`, a 0…1 float) is read and written; if the device has no settable volume, it falls back to AppleScript (`output volume of (get volume settings)` / `set volume output volume N`). It does not change the mute state.
  * **Brightness** – the private *DisplayServices* framework, loaded at run time with `dlopen`/`dlsym` (`DisplayServicesGetBrightness` / `DisplayServicesSetBrightness`) on the built-in display (or the main display if there is none). If that API is missing or fails for the display, it falls back to posting the system **brightness-up / brightness-down media keys** (`NX_KEYTYPE_BRIGHTNESS_UP/DOWN`) to step toward the target, in the keys' 16 steps. The keys give no feedback, so the fallback works from an estimated level: the first time it drives the display to the nearer end of the range and steps back, afterwards it steps relative to its estimate (which drifts if you change brightness elsewhere). **Built-in displays (and Apple displays) are supported; many external monitors are not** – with those, brightness may do nothing or only follow the keys. Because DisplayServices is private API, a future macOS could change it (then the key fallback applies); the app is not suitable for the Mac App Store anyway.

## Settings (gear icon)

Opens a half-height sheet over the grid (pull up for full height) so changes can be seen live. Everything is stored in `UserDefaults` and the grid, hotkey strip and keyboard update immediately.

| Section | Setting | Range / default |
|---------|---------|-----------------|
| Dot grid | Dot spacing | 14–40 pt / 24 |
| | Dot size (idle radius) | 0.6–3.0 pt / 1.2 |
| | Growth under finger (extra radius) | 0–6 pt / 2.2 |
| | Highlight radius | 40–160 pt / 90 |
| Feel | Haptics on/off | on |
| | Pointer speed | 0.5–3.0× / 1.0 |
| Typing | Show keyboard for text fields | on |
| Hotkey strip | Slot 1 … Slot 6 → open the hotkey editor (name, action, app or shortcut, clear) | not assigned |
| Edge swipes | Left edge / Right edge (swipe down) → same hotkey editor | not assigned |

### Hotkeys (hotkey strip) and the hotkey editor

A strip of up to six pill buttons sits in the bottom margin, centred under the grid. **Only assigned slots are shown** (nothing is shown until you assign one). Tap a button to run it. Tap a slot (or an edge row) in settings to open the **hotkey editor**, where you can at any time:

* **Rename** it: the *Name* field is the text on the strip button (max 24 characters). Leave it empty to use the default: the app name, or the shortcut glyphs.
* **Change the action**: *Open app* or *Keyboard shortcut*.
  * *Open app*: pick any app from the searchable list sent by the Mac (name + bundle id; the Mac must be running and connected). Tapping the button sends `openApp(bundleId)` and the Mac opens the app, or brings it to the front if it is already running (`NSWorkspace.openApplication`, activating).
  * *Keyboard shortcut*: switch on any of **Command ⌘, Option ⌥, Control ⌃, Shift ⇧, Fn** and pick a **key**: letters, digits, punctuation (`- = [ ] \ ; ' , . / \``), arrows, Return, Tab, Esc, Space, Delete (backspace) and F1–F12. The editor shows the result Mac-style (modifiers in macOS order ⌃⌥⇧⌘, e.g. **⇧⌘4**). Tapping the button sends `keyShortcut(keyCode, modifiers)` and the Mac posts that key press (key down + key up) with the modifier flags using CGEvent (needs the Accessibility permission).
* **Clear** it ("Clear hotkey").

Changes are saved immediately (an incomplete choice, such as "Keyboard shortcut" without a key yet, is not saved and the previous hotkey stays). Edge-swipe assignments use the same editor, so a drag-down edge swipe can open an app or press a shortcut too.

**Migration:** hotkeys saved by v1.2 or earlier (a bare app per slot/edge) are converted to "Open app" hotkeys with the default name the first time they are read; nothing needs to be re-assigned.

### Typing

When the Mac reports that a text field is focused (text field, text area, combo box, search field, or editable content, detected through the Accessibility API, polled twice a second while a phone is connected), the iOS system keyboard slides up on the iPhone. Typed characters are sent as Unicode keyboard events, ⌫ as backspace and Return as Return. The keyboard hides when focus leaves the text field, and while the settings panel is open. Turn the feature off with **Settings → Show keyboard for text fields** (for physical-keyboard users).

## How it works

* **Discovery/transport** – Mac: `NWListener` (TCP, ephemeral port) publishing Bonjour service `_dottrackpad._tcp`. iPhone: `NWBrowser` for the same type, then `NWConnection`. `NSBonjourServices` + `NSLocalNetworkUsageDescription` are in the iOS `Info.plist` (also present in the Mac one). One phone at a time; a new connection replaces the old one. The iPhone reconnects automatically.
* **Protocol** – `Protocol.swift` (identical copy in both targets): each message is a 4-byte big-endian length followed by a UTF-8 JSON `Message`. Kinds: `move`, `click`, `rightClick`, `scroll`, `zoom`, `text`, `key` (phone → Mac); `focus` (Mac → phone); `requestApps` (phone → Mac), `appList` (Mac → phone, `apps: [{name, bundleId}]`), `openApp` (phone → Mac, `bundleId`); `getLevels` (phone → Mac), `levels` (Mac → phone, optional `volume` / `brightness`, 0…1), `setVolume` / `setBrightness` (phone → Mac, 0…1 in `volume` / `brightness`); `keyShortcut` (phone → Mac, `keyCode` = macOS virtual key code, `modifiers` = bit mask ⌘ 1, ⌥ 2, ⌃ 4, ⇧ 8, Fn 16). Frames larger than 256 KB are rejected (800 apps ≈ 90 KB).
* **Mac input** – `CGEvent` (mouse move/click, scroll wheel in pixel units, ⌘+/⌘− key events, `keyboardSetUnicodeString` for text) posted to `cghidEventTap`. Cursor movement is clamped to the union of active displays.
* **App list** – Hotkey app list: `AppScanner` reads `Contents/Info.plist` of every `.app` in `/Applications`, `/System/Applications` and `~/Applications` (up to 2 folder levels deep, e.g. `Utilities/`), skipping background-only helpers; name = `CFBundleDisplayName` → `CFBundleName` → file name; de-duplicated by bundle id, sorted by name, max 800.
* **Focus detection** – `AXUIElementCopyAttributeValue` on the system-wide focused element (falling back to the focused application), checking `AXRole` ∈ {AXTextField, AXTextArea, AXComboBox, AXSearchField}, subrole `AXSearchField`, or `AXEditable`.

## Project layout

```
dot-trackpad/
├── README.md
├── iOS/
│   ├── DotTrackpad.xcodeproj/
│   ├── project.yml                        (XcodeGen fallback)
│   └── DotTrackpad/
│       ├── AppDelegate.swift, SceneDelegate.swift
│       ├── TrackpadViewController.swift   (connection, keyboard, settings sheet, edge-gesture deferral)
│       ├── TrackpadView.swift             (centred dot grid, gear, hotkey strip, glow, haptics, touches → gestures)
│       ├── GestureLogic.swift             (acceleration, tap rules, scroll-vs-pinch, GridGeometry, EdgeSwipeDetector)
│       ├── SettingsViewController.swift   (settings table: sliders, switches, assignments)
│       ├── AppPickerViewController.swift  (searchable Mac app list)
│       ├── AppCatalog.swift               (latest app list from the Mac)
│       ├── Hotkey.swift                   (Hotkey / Shortcut / key catalog and glyphs)
│       ├── HotkeyEditorViewController.swift (rename, action, app or shortcut, clear)
│       ├── KeyPickerViewController.swift  (key list for shortcuts)
│       ├── LevelSliderView.swift          (volume / brightness slider)
│       ├── MacConnection.swift            (NWBrowser + NWConnection, auto-reconnect)
│       ├── Settings.swift                 (UserDefaults-backed AppSettings)
│       ├── Protocol.swift                 (shared)
│       ├── Assets.xcassets/               (black launch colour)
│       └── Info.plist
└── macOS/
    ├── DotTrackpadMac.xcodeproj/
    ├── project.yml
    └── DotTrackpadMac/
        ├── DotTrackpadMacApp.swift        (MenuBarExtra menu)
        ├── AppModel.swift                 (glue; handles requestApps / openApp / levels)
        ├── TrackpadServer.swift, InputInjector.swift, FocusMonitor.swift
        ├── AppScanner.swift               (installed-app list)
        ├── LevelController.swift          (volume via CoreAudio, brightness via DisplayServices / media keys)
        ├── BrightnessStepper.swift        (key-press planning for the brightness fallback)
        ├── Protocol.swift                 (identical copy)
        └── Info.plist                     (LSUIElement = YES)
```

## Known limitations

* **Not compiled or run on real hardware by the author.** The code was written and checked on a Linux machine without Xcode (see "Validation"). Expect that the first Xcode build may show a warning or need a small fix – please report it.
* No click-and-drag (press-hold-move), no tap-to-drag, no three-finger gestures, no system-level pinch/magnify gesture (⌘+/⌘− is used instead).
* Cursor movement is relative only; tuning constants live in `GestureLogic.swift` (`PointerAcceleration`, `TapRules`, `ScrollTuning`, `EdgeSwipeDetector`, `GridGeometry`) and `InputInjector.zoomStep`.
* Edge swipes hold the cursor still for the first few points of a drag that starts in the 28 pt edge strip (only when that edge has an app assigned).
* Keyboard shortcuts are posted as ordinary key events with modifier flags, so shortcuts that the system handles below the app level (e.g. ⌘Tab app switcher, some Fn/media combinations) may not fire; modifier keys themselves are not pressed separately. The hotkey strip buttons show at most ~104 pt of text each (names are truncated / shrunk).
* The app list only contains apps from the three scanned folders (e.g. Finder, which lives in `/System/Library/CoreServices`, is not listed) and uses non-localised names; apps in folders nested deeper than 2 levels are skipped. `openApp` accepts any bundle id the phone sends – the Mac app trusts whoever is connected.
* Only one Mac is used: if several Macs run the app on the network, the phone connects to the first one found (sorted by name). One phone at a time per Mac. Settings and assignments are stored on the phone and are not per-Mac.
* Text-field detection depends on the target app exposing Accessibility info. Some apps (Electron apps, Chrome with accessibility off, games, remote-desktop views) don't report a focused text field, so the keyboard won't appear automatically.
* Typing uses Unicode events, so keyboard shortcuts with modifiers, arrow keys, Tab, and Esc are not available from the on-screen keyboard (only characters, ⌫ and Return). Secure-input fields (e.g. macOS password prompts) block synthetic key events.
* Traffic is plain TCP on the local network without encryption or pairing: anyone on the same network who finds the service could connect and control the Mac. Use on trusted networks only.
* The iPhone shows no connection state; if nothing happens, check the Mac menu-bar status and that both devices are on the same network with Local Network permission granted.
* No app icons (default icons), as no artwork was requested.
* The Mac app is unsandboxed and unsigned for distribution (no notarisation / hardened-runtime setup).

## Validation performed (author's environment: Linux, no Xcode)

* The platform-independent logic – `Protocol.swift`, `GestureLogic.swift` (acceleration, tap rules, scroll/pinch classifier, `GridGeometry`, `EdgeSwipeDetector` incl. inward swipes, `LevelMapping`, `LevelThrottle`), `Settings.swift`, `Hotkey.swift`, `AppCatalog.swift`, `AppScanner.swift` and `BrightnessStepper.swift` – was compiled with the Swift 6.0.3 Linux compiler (`-swift-version 5`, warnings as errors) and exercised by a 109-check test run:
  * message round-trips for every kind (incl. `getLevels`, `levels` with missing fields, `setVolume`, `setBrightness`, `keyShortcut`), fragmented/coalesced decoding, oversize/malformed frames;
  * edge classification: drag-down cases (unchanged), inward swipes from both borders (with and without an assigned app, below threshold, slope tolerance, diagonals falling back to cursor drags, outward drags, fires once, must start in the zone);
  * slider mapping and send throttling (100 Hz drag → ~20 Hz), brightness-key planning;
  * shortcut model: key-code table checked against macOS virtual key codes, unique codes, glyph rendering (⇧⌘4, fn ⌃⌥⇧⌘A), validity, shortcut → message, modifier bit values;
  * hotkey settings: JSON round-trip, default/custom/blank/trimmed/truncated names, persistence of app and shortcut hotkeys on slots and edges, rename, invalid data, **migration** of the old bare-app format (slot and edge) including rewrite to the new format;
  * grid centring, settings clamping, app scanner on a fake Applications tree, etc.
* All Swift files parse (`swiftc -parse`) and the two byte-identical `Protocol.swift` copies were diffed; the networking files (`MacConnection.swift`, `TrackpadServer.swift`) additionally type-check against a hand-written stand-in for Network.framework.
* Both `project.pbxproj` files were generated by script and loaded with an independent pbxproj parser: all object references resolve and every referenced file exists and every Swift file on disk is in its project. All `.plist` / `.json` / `project.yml` files parse.
* **Not verified:** everything that needs UIKit/AppKit/CoreGraphics/CoreAudio/ApplicationServices (touch view, slider view, settings / hotkey editor / pickers, `InputInjector` incl. shortcut posting, `LevelController` incl. DisplayServices symbols and the media-key fallback, `FocusMonitor`, `NSWorkspace` launching), the Xcode project opening cleanly, Bonjour discovery, permission prompts, haptics, sheet behaviour, whether DisplayServices works on a given Mac / display, and the feel of the gesture thresholds.
