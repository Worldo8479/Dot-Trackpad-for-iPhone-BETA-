import UIKit

/// Lets the user pick one of the Mac's apps (sent by the Mac) for a hotkey (called back with the choice).
final class AppPickerViewController: UITableViewController, UISearchResultsUpdating {
    private let currentBundleId: String?
    private let onPick: (AppInfo?) -> Void
    private var filtered: [AppInfo] = []
    private var query = ""

    /// `onPick` is called with the chosen app, or nil for "Not assigned".
    init(title: String, currentBundleId: String?, onPick: @escaping (AppInfo?) -> Void) {
        self.currentBundleId = currentBundleId
        self.onPick = onPick
        super.init(style: .insetGrouped)
        self.title = title
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        let search = UISearchController(searchResultsController: nil)
        search.obscuresBackgroundDuringPresentation = false
        search.searchResultsUpdater = self
        search.searchBar.placeholder = "Search apps"
        navigationItem.searchController = search
        navigationItem.hidesSearchBarWhenScrolling = false

        NotificationCenter.default.addObserver(self, selector: #selector(catalogChanged),
                                               name: AppCatalog.didUpdate, object: nil)
        applyFilter()
        AppCatalog.shared.request()
    }

    @objc private func catalogChanged() {
        applyFilter()
    }

    func updateSearchResults(for searchController: UISearchController) {
        query = searchController.searchBar.text ?? ""
        applyFilter()
    }

    private func applyFilter() {
        let all = AppCatalog.shared.apps
        let trimmed = query.trimmingCharacters(in: .whitespaces)
        filtered = trimmed.isEmpty ? all : all.filter { $0.name.localizedCaseInsensitiveContains(trimmed) }
        tableView.reloadData()
    }

    // Section 0: "Not assigned". Section 1: apps (or a hint while the list is empty).

    override func numberOfSections(in tableView: UITableView) -> Int { 2 }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 { return 1 }
        return filtered.isEmpty ? 1 : filtered.count
    }

    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        guard section == 1, AppCatalog.shared.apps.isEmpty else { return nil }
        return "The app list comes from the Mac app. Make sure it is running and connected."
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .subtitle, reuseIdentifier: nil)
        let current = currentBundleId
        if indexPath.section == 0 {
            cell.textLabel?.text = "Not assigned"
            cell.accessoryType = current == nil ? .checkmark : .none
        } else if filtered.isEmpty {
            cell.textLabel?.text = AppCatalog.shared.apps.isEmpty ? "No apps yet…" : "No matches"
            cell.textLabel?.textColor = .secondaryLabel
            cell.selectionStyle = .none
        } else {
            let app = filtered[indexPath.row]
            cell.textLabel?.text = app.name
            cell.detailTextLabel?.text = app.bundleId
            cell.detailTextLabel?.textColor = .secondaryLabel
            cell.accessoryType = current == app.bundleId ? .checkmark : .none
        }
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.section == 0 {
            onPick(nil)
        } else if !filtered.isEmpty {
            onPick(filtered[indexPath.row])
        } else {
            return
        }
        navigationController?.popViewController(animated: true)
    }
}
