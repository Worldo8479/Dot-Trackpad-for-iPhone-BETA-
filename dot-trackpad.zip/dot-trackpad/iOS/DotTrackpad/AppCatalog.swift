import Foundation

/// The list of Mac apps most recently sent by the Mac (used by the app pickers in Settings).
final class AppCatalog {
    static let shared = AppCatalog()
    static let didUpdate = Notification.Name("DotTrackpadAppCatalogDidUpdate")

    private(set) var apps: [AppInfo] = []

    /// Set by the view controller: asks the Mac to send its app list.
    var requestHandler: (() -> Void)?

    private init() {}

    func update(_ newApps: [AppInfo]) {
        apps = newApps
        NotificationCenter.default.post(name: Self.didUpdate, object: self)
    }

    func request() {
        requestHandler?()
    }
}
