import Foundation

// Pure gesture / layout math (no UIKit) so it stays easy to reason about and test.

enum PointerAcceleration {
    /// Base multiplier from phone points to Mac points (scaled by the "pointer speed" setting).
    static let baseGain = 1.6
    /// Finger speed (points per touch event) at which the boost adds +100%.
    static let speedScale = 12.0
    /// Maximum extra boost (2.0 = up to 3x the base gain on fast flicks).
    static let maxBoost = 2.0

    /// `speed` is the user's pointer-speed setting (1.0 = default).
    static func apply(dx: Double, dy: Double, speed: Double = 1.0) -> (dx: Double, dy: Double) {
        let fingerSpeed = (dx * dx + dy * dy).squareRoot()
        let gain = baseGain * speed * (1 + min(fingerSpeed / speedScale, maxBoost))
        return (dx * gain, dy * gain)
    }
}

enum TapRules {
    /// A touch sequence only counts as a tap if no finger moved further than this (points).
    static let slop = 10.0
    static let maxOneFingerDuration = 0.30
    static let maxTwoFingerDuration = 0.45

    /// Returns the click to send when all fingers have lifted, or nil if it was not a tap.
    static func classify(maxTouches: Int, duration: Double, travel: Double) -> Message? {
        guard travel < slop else { return nil }
        switch maxTouches {
        case 1:
            return duration < maxOneFingerDuration ? Message.click : nil
        case 2:
            return duration < maxTwoFingerDuration ? Message.rightClick : nil
        default:
            return nil
        }
    }
}

enum TwoFingerDecision: Equatable {
    case scroll
    case pinch
}

enum TwoFingerClassifier {
    /// Minimum accumulated motion (points) before we commit to scroll or pinch.
    static let commitThreshold = 8.0

    /// `movement`: accumulated distance travelled by the fingers' centroid.
    /// `pinch`: accumulated absolute change of the distance between the fingers.
    static func decide(movement: Double, pinch: Double) -> TwoFingerDecision? {
        guard max(movement, pinch) >= commitThreshold else { return nil }
        return pinch > movement ? .pinch : .scroll
    }
}

enum ScrollTuning {
    /// Phone points of two-finger travel -> Mac scroll pixels.
    static let gain = 2.0
}

/// Where the dot grid lives on screen: centred, with visible margins on every side.
/// The top margin holds the gear icon, the bottom margin the hotkey strip.
struct GridGeometry: Equatable {
    /// Visible margin added on top of the larger of the top/bottom safe-area insets.
    static let verticalMargin = 44.0
    /// Visible margin added on top of the larger of the left/right safe-area insets.
    static let horizontalMargin = 20.0

    var x: Double
    var y: Double
    var width: Double
    var height: Double

    var maxX: Double { x + width }
    var maxY: Double { y + height }

    /// Insets are symmetric (max of the two opposite safe-area insets) so the grid is exactly centred.
    static func make(boundsWidth: Double, boundsHeight: Double,
                     safeTop: Double, safeLeft: Double, safeBottom: Double, safeRight: Double) -> GridGeometry {
        let v = max(safeTop, safeBottom) + verticalMargin
        let h = max(safeLeft, safeRight) + horizontalMargin
        return GridGeometry(x: h, y: v,
                            width: max(0, boundsWidth - 2 * h),
                            height: max(0, boundsHeight - 2 * v))
    }

    func contains(x px: Double, y py: Double) -> Bool {
        px >= x && px <= maxX && py >= y && py <= maxY
    }
}

/// Classifies a drag that starts in the left/right edge zone just inside the dot grid:
///
/// * mostly-vertical **downward** drag  -> `.triggered(edge)`        (open the app assigned to that edge;
///   only when an app is assigned to that edge)
/// * mostly-horizontal **inward** drag  -> `.triggeredInward(edge)`  (left: volume slider, right: brightness
///   slider; works whether or not an app is assigned)
/// * anything else                      -> `.notEdge`                (ordinary cursor drag)
///
/// Feed it the first touch position (`begin`) and every later position of that same finger
/// (`update`). While the outcome is `.pending` the caller must hold the cursor still; once it
/// is `.notEdge` the touch is an ordinary cursor drag; the two `triggered` outcomes fire exactly once.
struct EdgeSwipeDetector {
    enum Edge: String, Equatable {
        case left
        case right
    }

    enum Outcome: Equatable {
        case notEdge
        case pending
        case triggered(Edge)         // drag down: open the app assigned to this edge
        case triggeredInward(Edge)   // drag toward the centre: show the volume (left) / brightness (right) slider
    }

    /// Width of the start zone, measured inward from the grid's left/right edge (points).
    static let startZone = 28.0
    /// Downward travel needed to trigger (points).
    static let triggerDistance = 70.0
    /// Downward travel must be at least this many times the sideways travel.
    static let verticalDominance = 2.0
    /// Sideways travel that cancels the drag-down swipe (it becomes a cursor drag).
    static let maxSideways = 24.0
    /// Upward travel that cancels the drag-down swipe.
    static let maxUpward = 12.0
    /// Inward (toward the grid centre) travel needed to trigger the slider (points).
    static let inwardDistance = 36.0
    /// Inward travel must be at least this many times the vertical travel.
    static let inwardDominance = 2.0
    /// Vertical wobble always tolerated while a swipe may still turn out to be inward.
    static let inwardWobble = 14.0
    /// Travel away from the centre that cancels the inward swipe.
    static let maxOutward = 12.0

    private enum State {
        case idle
        case pending(edge: Edge, startX: Double, startY: Double, assigned: Bool)
    }

    private var state = State.idle

    /// `isAssigned` tells whether an app is assigned to an edge (needed for drag-down only;
    /// inward swipes start in the zone regardless).
    mutating func begin(x: Double, y: Double, gridMinX: Double, gridMaxX: Double,
                        isAssigned: (Edge) -> Bool) {
        state = .idle
        if x >= gridMinX && x <= gridMinX + Self.startZone {
            state = .pending(edge: .left, startX: x, startY: y, assigned: isAssigned(.left))
        } else if x <= gridMaxX && x >= gridMaxX - Self.startZone {
            state = .pending(edge: .right, startX: x, startY: y, assigned: isAssigned(.right))
        }
    }

    mutating func cancel() {
        state = .idle
    }

    mutating func update(x: Double, y: Double) -> Outcome {
        guard case let .pending(edge, startX, startY, assigned) = state else { return .notEdge }
        let dx = x - startX
        let dy = y - startY
        let inward = edge == .left ? dx : -dx

        if inward >= Self.inwardDistance && inward >= Self.inwardDominance * abs(dy) {
            state = .idle
            return .triggeredInward(edge)
        }
        if assigned && dy >= Self.triggerDistance && dy >= Self.verticalDominance * abs(dx) {
            state = .idle
            return .triggered(edge)
        }

        let inwardStillPossible = inward >= -Self.maxOutward
            && abs(dy) <= max(Self.inwardWobble, inward / Self.inwardDominance)
        let downStillPossible = assigned && abs(dx) <= Self.maxSideways && dy >= -Self.maxUpward
        if inwardStillPossible || downStillPossible {
            return .pending
        }
        state = .idle
        return .notEdge
    }
}

/// Maps a finger position on a vertical level slider to a value (top = 1, bottom = 0).
enum LevelMapping {
    static func value(forY y: Double, height: Double, inset: Double) -> Double {
        let usable = height - 2 * inset
        guard usable > 0 else { return 0 }
        return min(max((height - inset - y) / usable, 0), 1)
    }
}

/// Limits how often slider values are sent to the Mac while the finger drags.
/// The final value (finger lifted) is always sent unless it equals what was sent last.
struct LevelThrottle {
    static let minInterval = 0.05   // seconds between sends while dragging
    static let minDelta = 0.004     // ignore changes smaller than this while dragging

    private var lastTime: Double?
    private var lastValue: Double?

    mutating func shouldSend(value: Double, now: Double, isFinal: Bool) -> Bool {
        if isFinal {
            if let last = lastValue, last == value { return false }
        } else {
            if let t = lastTime, now - t < Self.minInterval { return false }
            if let last = lastValue, abs(last - value) < Self.minDelta { return false }
        }
        lastTime = now
        lastValue = value
        return true
    }

    mutating func reset() {
        lastTime = nil
        lastValue = nil
    }
}
