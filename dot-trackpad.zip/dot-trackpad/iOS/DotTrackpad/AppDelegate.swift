import UIKit

@main
final class AppDelegate: UIResponder, UIApplicationDelegate {
    // The window is created per scene in SceneDelegate (see Info.plist scene manifest).
}
