import Foundation

/// Scans application folders for `.app` bundles and returns name + bundle id pairs.
enum AppScanner {
    /// Upper bound so the app list always fits in one protocol frame.
    static let maxApps = 800
    /// How many folder levels below each root are searched (e.g. /Applications/Utilities/Foo.app = 1).
    static let maxDepth = 2

    static var defaultDirectories: [URL] {
        [
            URL(fileURLWithPath: "/Applications", isDirectory: true),
            URL(fileURLWithPath: "/System/Applications", isDirectory: true),
            FileManager.default.homeDirectoryForCurrentUser.appendingPathComponent("Applications", isDirectory: true),
        ]
    }

    /// Returns apps sorted by name; duplicates (same bundle id) are collapsed to the first one found.
    static func installedApps(in directories: [URL] = defaultDirectories) -> [AppInfo] {
        var byBundleId: [String: AppInfo] = [:]
        for directory in directories {
            scan(directory, depth: 0, into: &byBundleId)
        }
        let sorted = byBundleId.values.sorted {
            let order = $0.name.localizedCaseInsensitiveCompare($1.name)
            return order == .orderedSame ? $0.bundleId < $1.bundleId : order == .orderedAscending
        }
        return Array(sorted.prefix(maxApps))
    }

    private static func scan(_ directory: URL, depth: Int, into result: inout [String: AppInfo]) {
        guard let entries = try? FileManager.default.contentsOfDirectory(
            at: directory,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]) else { return }

        for entry in entries {
            if entry.pathExtension.lowercased() == "app" {
                if let app = readApp(at: entry), result[app.bundleId] == nil {
                    result[app.bundleId] = app
                }
            } else if depth < maxDepth,
                      (try? entry.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory == true {
                scan(entry, depth: depth + 1, into: &result)
            }
        }
    }

    private static func readApp(at url: URL) -> AppInfo? {
        let plistURL = url.appendingPathComponent("Contents/Info.plist")
        guard let data = try? Data(contentsOf: plistURL),
              let object = try? PropertyListSerialization.propertyList(from: data, options: [], format: nil),
              let info = object as? [String: Any],
              let bundleId = info["CFBundleIdentifier"] as? String, !bundleId.isEmpty else { return nil }

        // Helper processes that are not meant to be launched by the user.
        if (info["LSBackgroundOnly"] as? Bool) == true { return nil }

        let fileName = url.deletingPathExtension().lastPathComponent
        let candidates = [info["CFBundleDisplayName"] as? String, info["CFBundleName"] as? String, fileName]
        let name = candidates.compactMap { $0?.trimmingCharacters(in: .whitespaces) }.first { !$0.isEmpty } ?? fileName
        return AppInfo(name: name, bundleId: bundleId)
    }
}
