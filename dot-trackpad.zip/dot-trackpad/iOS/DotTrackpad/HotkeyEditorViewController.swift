import UIKit

/// Edits one hotkey (a strip slot or an edge swipe): its name, its action (open an app or press a
/// keyboard shortcut) and can clear it. Changes are saved immediately.
final class HotkeyEditorViewController: UITableViewController, UITextFieldDelegate {
    private enum ActionType: Int {
        case app = 0
        case shortcut = 1
    }

    private enum Section: Int, CaseIterable {
        case name, action, details, clear
    }

    private let target: AppTarget
    private var actionType: ActionType
    private var name: String
    private var app: AppInfo?
    private var keyCode: Int?
    private var modifiers: Int

    private static let modifierRows: [(title: String, bit: Int)] = [
        ("Command ⌘", ShortcutModifier.command),
        ("Option ⌥", ShortcutModifier.option),
        ("Control ⌃", ShortcutModifier.control),
        ("Shift ⇧", ShortcutModifier.shift),
        ("Fn", ShortcutModifier.fn),
    ]

    init(title: String, target: AppTarget) {
        self.target = target
        let existing = AppSettings.hotkey(for: target)
        name = existing?.name ?? ""
        actionType = .app
        modifiers = 0
        if let existing = existing {
            switch existing.action {
            case .app(let info):
                app = info
            case .shortcut(let shortcut):
                actionType = .shortcut
                keyCode = shortcut.keyCode
                modifiers = shortcut.modifiers
            }
        }
        super.init(style: .insetGrouped)
        self.title = title
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tableView.reloadData()
        AppCatalog.shared.request()
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        view.endEditing(true)
        persist()
    }

    // MARK: Model

    private var currentShortcut: Shortcut? {
        keyCode.map { Shortcut(keyCode: $0, modifiers: modifiers) }
    }

    /// The hotkey described by the editor, or nil while the chosen action is incomplete.
    private var draftHotkey: Hotkey? {
        switch actionType {
        case .app:
            return app.map { Hotkey(name: name, action: .app($0)) }
        case .shortcut:
            return currentShortcut.map { Hotkey(name: name, action: .shortcut($0)) }
        }
    }

    /// Saves the hotkey. An incomplete draft (e.g. "Keyboard shortcut" with no key yet) leaves the stored one unchanged.
    private func persist() {
        guard let hotkey = draftHotkey else { return }
        AppSettings.setHotkey(hotkey, for: target)
    }

    private var defaultNamePlaceholder: String {
        draftHotkey?.defaultName ?? "App name or shortcut"
    }

    // MARK: Table

    override func numberOfSections(in tableView: UITableView) -> Int { Section.allCases.count }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        switch Section(rawValue: section)! {
        case .name: return "Name"
        case .action: return "Action"
        case .details: return actionType == .app ? "App" : "Keyboard shortcut"
        case .clear: return nil
        }
    }

    override func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        switch Section(rawValue: section)! {
        case .name:
            return "Shown on the hotkey button. Leave it empty to use \"\(defaultNamePlaceholder)\"."
        case .action:
            return draftHotkey == nil ? "Not saved yet: choose \(actionType == .app ? "an app" : "a key") below." : nil
        case .details, .clear:
            return nil
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        switch Section(rawValue: section)! {
        case .name, .action, .clear:
            return 1
        case .details:
            return actionType == .app ? 1 : 2 + Self.modifierRows.count   // preview, modifiers, key
        }
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        switch Section(rawValue: indexPath.section)! {
        case .name:
            return nameCell()
        case .action:
            return actionCell()
        case .details:
            return detailsCell(row: indexPath.row)
        case .clear:
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            cell.textLabel?.text = "Clear hotkey"
            cell.textLabel?.textColor = .systemRed
            cell.textLabel?.textAlignment = .center
            return cell
        }
    }

    private func nameCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        let field = UITextField()
        field.text = name
        field.placeholder = defaultNamePlaceholder
        field.clearButtonMode = .whileEditing
        field.returnKeyType = .done
        field.autocorrectionType = .no
        field.delegate = self
        field.accessibilityLabel = "Hotkey name"
        field.translatesAutoresizingMaskIntoConstraints = false
        field.addAction(UIAction { [weak self, weak field] _ in
            guard let self = self, let field = field else { return }
            self.name = String((field.text ?? "").prefix(Hotkey.maxNameLength))
            if field.text != self.name { field.text = self.name }
            self.persist()
        }, for: .editingChanged)
        cell.contentView.addSubview(field)
        NSLayoutConstraint.activate([
            field.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 12),
            field.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -12),
            field.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            field.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
        ])
        return cell
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    private func actionCell() -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.selectionStyle = .none
        let control = UISegmentedControl(items: ["Open app", "Keyboard shortcut"])
        control.selectedSegmentIndex = actionType.rawValue
        control.addAction(UIAction { [weak self, weak control] _ in
            guard let self = self, let control = control,
                  let type = ActionType(rawValue: control.selectedSegmentIndex) else { return }
            self.view.endEditing(true)
            self.actionType = type
            self.persist()
            self.tableView.reloadData()
        }, for: .valueChanged)
        control.translatesAutoresizingMaskIntoConstraints = false
        cell.contentView.addSubview(control)
        NSLayoutConstraint.activate([
            control.topAnchor.constraint(equalTo: cell.contentView.topAnchor, constant: 8),
            control.bottomAnchor.constraint(equalTo: cell.contentView.bottomAnchor, constant: -8),
            control.leadingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.leadingAnchor),
            control.trailingAnchor.constraint(equalTo: cell.contentView.layoutMarginsGuide.trailingAnchor),
        ])
        return cell
    }

    private func detailsCell(row: Int) -> UITableViewCell {
        if actionType == .app {
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            cell.textLabel?.text = "App"
            cell.detailTextLabel?.text = app?.name ?? "Choose…"
            cell.accessoryType = .disclosureIndicator
            return cell
        }
        if row == 0 {
            let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
            cell.selectionStyle = .none
            cell.textLabel?.text = "Shortcut"
            cell.detailTextLabel?.text = currentShortcut?.glyphs ?? "Choose a key"
            cell.detailTextLabel?.font = .systemFont(ofSize: 20, weight: .semibold)
            return cell
        }
        if row <= Self.modifierRows.count {
            let spec = Self.modifierRows[row - 1]
            let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
            cell.selectionStyle = .none
            cell.textLabel?.text = spec.title
            let toggle = UISwitch()
            toggle.isOn = modifiers & spec.bit != 0
            toggle.addAction(UIAction { [weak self, weak toggle] _ in
                guard let self = self, let toggle = toggle else { return }
                if toggle.isOn { self.modifiers |= spec.bit } else { self.modifiers &= ~spec.bit }
                self.persist()
                self.tableView.reloadRows(at: [IndexPath(row: 0, section: Section.details.rawValue)], with: .none)
            }, for: .valueChanged)
            cell.accessoryView = toggle
            return cell
        }
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        cell.textLabel?.text = "Key"
        cell.detailTextLabel?.text = keyCode.flatMap { KeyCatalog.key(forCode: $0)?.label } ?? "Choose…"
        cell.accessoryType = .disclosureIndicator
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        view.endEditing(true)
        switch Section(rawValue: indexPath.section)! {
        case .details:
            if actionType == .app {
                let picker = AppPickerViewController(title: "App", currentBundleId: app?.bundleId) { [weak self] picked in
                    self?.app = picked
                    self?.persist()
                }
                navigationController?.pushViewController(picker, animated: true)
            } else if indexPath.row == 1 + Self.modifierRows.count {
                let picker = KeyPickerViewController(currentKeyCode: keyCode) { [weak self] key in
                    self?.keyCode = key.code
                    self?.persist()
                }
                navigationController?.pushViewController(picker, animated: true)
            }
        case .clear:
            name = ""
            app = nil
            keyCode = nil
            modifiers = 0
            AppSettings.setHotkey(nil, for: target)
            navigationController?.popViewController(animated: true)
        case .name, .action:
            break
        }
    }
}
