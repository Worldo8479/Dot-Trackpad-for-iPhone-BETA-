import Foundation
import Network

/// Discovers the Mac app over Bonjour, connects over TCP and exchanges `Message`s.
/// Automatically reconnects. All state is confined to `queue`.
final class MacConnection {
    /// Called on the main queue whenever the Mac reports a focus change
    /// (and with `false` whenever the connection is lost or stopped).
    var onFocusChange: ((Bool) -> Void)?
    /// Called on the main queue when the Mac reports its volume / brightness (0...1, nil if unknown).
    var onLevels: ((Double?, Double?) -> Void)?

    private let queue = DispatchQueue(label: "dottrackpad.connection")
    private var browser: NWBrowser?
    private var connection: NWConnection?
    private var decoder = FrameDecoder()
    private var running = false
    private var retryWork: DispatchWorkItem?

    // MARK: Public API (any thread)

    func start() {
        queue.async {
            guard !self.running else { return }
            self.running = true
            self.beginBrowsing()
        }
    }

    func stop() {
        queue.async {
            self.running = false
            self.teardown()
            self.notifyFocus(false)
        }
    }

    func send(_ message: Message) {
        queue.async {
            guard let connection = self.connection,
                  case .ready = connection.state,
                  let frame = FrameCodec.encode(message) else { return }
            connection.send(content: frame, completion: .contentProcessed { _ in })
        }
    }

    // MARK: Browsing

    private func beginBrowsing() {
        guard running, browser == nil, connection == nil else { return }

        let browser = NWBrowser(for: .bonjour(type: Wire.serviceType, domain: nil), using: .tcp)
        self.browser = browser

        browser.browseResultsChangedHandler = { [weak self] results, _ in
            guard let self = self, self.running, self.connection == nil else { return }
            let sorted = results.sorted { "\($0.endpoint)" < "\($1.endpoint)" }
            if let first = sorted.first {
                self.connect(to: first.endpoint)
            }
        }
        browser.stateUpdateHandler = { [weak self, weak browser] state in
            guard let self = self, let browser = browser, browser === self.browser else { return }
            if case .failed = state {
                self.browser?.cancel()
                self.browser = nil
                self.scheduleRetry()
            }
        }
        browser.start(queue: queue)
    }

    // MARK: Connecting

    private func connect(to endpoint: NWEndpoint) {
        browser?.cancel()
        browser = nil

        let tcp = NWProtocolTCP.Options()
        tcp.noDelay = true
        tcp.enableKeepalive = true
        tcp.keepaliveIdle = 5
        tcp.keepaliveInterval = 2
        tcp.keepaliveCount = 3
        let parameters = NWParameters(tls: nil, tcp: tcp)

        let connection = NWConnection(to: endpoint, using: parameters)
        self.connection = connection
        decoder = FrameDecoder()

        connection.stateUpdateHandler = { [weak self, weak connection] state in
            guard let self = self, let connection = connection, connection === self.connection else { return }
            switch state {
            case .ready:
                self.receive(on: connection)
            case .failed, .cancelled, .waiting:
                self.drop(connection)
            default:
                break
            }
        }
        connection.start(queue: queue)
    }

    private func receive(on connection: NWConnection) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 64 * 1024) { [weak self] data, _, isComplete, error in
            guard let self = self, connection === self.connection else { return }

            if let data = data, !data.isEmpty {
                self.decoder.append(data)
                do {
                    for message in try self.decoder.drain() {
                        switch message.kind {
                        case .focus:
                            self.notifyFocus(message.focused ?? false)
                        case .appList:
                            let apps = message.apps ?? []
                            DispatchQueue.main.async { AppCatalog.shared.update(apps) }
                        case .levels:
                            let volume = message.volume
                            let brightness = message.brightness
                            DispatchQueue.main.async { [weak self] in self?.onLevels?(volume, brightness) }
                        default:
                            break
                        }
                    }
                } catch {
                    self.drop(connection)
                    return
                }
            }

            if error != nil || isComplete {
                self.drop(connection)
            } else {
                self.receive(on: connection)
            }
        }
    }

    private func drop(_ dropped: NWConnection) {
        guard dropped === connection else { return }
        dropped.cancel()
        connection = nil
        decoder = FrameDecoder()
        notifyFocus(false)
        scheduleRetry()
    }

    private func scheduleRetry() {
        guard running else { return }
        retryWork?.cancel()
        let work = DispatchWorkItem { [weak self] in
            guard let self = self else { return }
            self.browser?.cancel()
            self.browser = nil
            self.beginBrowsing()
        }
        retryWork = work
        queue.asyncAfter(deadline: .now() + 1.0, execute: work)
    }

    private func teardown() {
        retryWork?.cancel()
        retryWork = nil
        browser?.cancel()
        browser = nil
        let old = connection
        connection = nil
        old?.cancel()
    }

    private func notifyFocus(_ focused: Bool) {
        DispatchQueue.main.async { [weak self] in
            self?.onFocusChange?(focused)
        }
    }
}
