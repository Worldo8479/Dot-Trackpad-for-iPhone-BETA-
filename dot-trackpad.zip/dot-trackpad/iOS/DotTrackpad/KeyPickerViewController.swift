import UIKit

/// Lists every key a shortcut can use, grouped (letters, digits, punctuation, arrows, special, function).
final class KeyPickerViewController: UITableViewController {
    private let currentKeyCode: Int?
    private let onPick: (KeyDef) -> Void

    init(currentKeyCode: Int?, onPick: @escaping (KeyDef) -> Void) {
        self.currentKeyCode = currentKeyCode
        self.onPick = onPick
        super.init(style: .insetGrouped)
        title = "Key"
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) is not used")
    }

    override func numberOfSections(in tableView: UITableView) -> Int { KeyCatalog.groupOrder.count }

    override func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        KeyCatalog.groupOrder[section]
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        KeyCatalog.keys(inGroup: KeyCatalog.groupOrder[section]).count
    }

    private func key(at indexPath: IndexPath) -> KeyDef {
        KeyCatalog.keys(inGroup: KeyCatalog.groupOrder[indexPath.section])[indexPath.row]
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let key = key(at: indexPath)
        let cell = UITableViewCell(style: .value1, reuseIdentifier: nil)
        cell.textLabel?.text = key.label
        cell.detailTextLabel?.text = key.glyph
        cell.accessoryType = key.code == currentKeyCode ? .checkmark : .none
        return cell
    }

    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        onPick(key(at: indexPath))
        navigationController?.popViewController(animated: true)
    }
}
