import Foundation
import ApplicationServices
import AppKit

/// Glue between the network server, the input injector, the focus monitor and the menu.
final class AppModel: ObservableObject {
    static let shared = AppModel()

    @Published var connectionStatus = "Starting…"
    @Published var accessibilityTrusted = AXIsProcessTrusted()

    private let server = TrackpadServer()
    private let injector = InputInjector()
    private let focusMonitor = FocusMonitor()
    private let levels = LevelController()   // main thread only
    private var trustTimer: Timer?
    private var started = false

    private init() {}

    func start() {
        guard !started else { return }
        started = true

        server.onStatus = { [weak self] status in
            DispatchQueue.main.async { self?.connectionStatus = status }
        }
        // Called on the server's queue; the injector is only ever touched from there.
        server.onMessage = { [weak self] message in
            guard let self = self else { return }
            switch message.kind {
            case .requestApps:
                self.sendAppList()
            case .openApp:
                if let bundleId = message.bundleId { self.openApp(bundleId: bundleId) }
            case .getLevels:
                DispatchQueue.main.async {
                    self.server.send(.levels(volume: self.levels.currentVolume(),
                                             brightness: self.levels.currentBrightness()))
                }
            case .setVolume:
                if let value = message.volume {
                    DispatchQueue.main.async { self.levels.setVolume(value) }
                }
            case .setBrightness:
                if let value = message.brightness {
                    DispatchQueue.main.async { self.levels.setBrightness(value) }
                }
            default:
                self.injector.handle(message)
            }
        }
        server.onConnectionChange = { [weak self] connected in
            self?.focusMonitor.setActive(connected)
        }
        focusMonitor.onChange = { [weak self] focused in
            self?.server.send(.focus(focused))
        }

        requestAccessibilityIfNeeded()
        server.start()

        trustTimer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true) { [weak self] _ in
            self?.refreshTrust()
        }
    }

    /// Scans the application folders off the main/server queues and sends the result to the phone.
    private func sendAppList() {
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            let apps = AppScanner.installedApps()
            self?.server.send(.appList(apps))
        }
    }

    /// Opens (or activates, if already running) the app with the given bundle identifier.
    private func openApp(bundleId: String) {
        DispatchQueue.main.async {
            guard let url = NSWorkspace.shared.urlForApplication(withBundleIdentifier: bundleId) else { return }
            let configuration = NSWorkspace.OpenConfiguration()
            configuration.activates = true
            NSWorkspace.shared.openApplication(at: url, configuration: configuration, completionHandler: nil)
        }
    }

    private func requestAccessibilityIfNeeded() {
        // "AXTrustedCheckOptionPrompt" is the value of kAXTrustedCheckOptionPrompt.
        let options = ["AXTrustedCheckOptionPrompt": true] as CFDictionary
        let trusted = AXIsProcessTrustedWithOptions(options)
        accessibilityTrusted = trusted
    }

    private func refreshTrust() {
        let trusted = AXIsProcessTrusted()
        if trusted != accessibilityTrusted {
            accessibilityTrusted = trusted
        }
    }
}
